package com.example.studybuddy.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.Data.StudySessionData
import com.example.studybuddy.R

class HostSessionAdapter(private var sessionList: List<StudySessionData>, private val listener: OnItemClickListener) : RecyclerView.Adapter
<HostSessionAdapter.MyViewHolder>() {
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvAcceptSessionName: TextView = itemView.findViewById(R.id.tvHostSessionName)
        val tvAcceptDetails: TextView = itemView.findViewById(R.id.tvHostDetails)
        val tvAcceptStartTime: TextView = itemView.findViewById(R.id.tvHostStartTime)
        val tvAcceptDate: TextView = itemView.findViewById(R.id.tvHostDate)
        val tvAcceptEndTime: TextView = itemView.findViewById(R.id.tvHostEndTime)
        val btnDelete: Button = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate( R.layout.session_host, parent, false )
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = sessionList[position]
        holder.tvAcceptSessionName.text = currentItem.sessionName
        holder.tvAcceptDetails.text=currentItem.details
        holder.tvAcceptDate.text=currentItem.date
        holder.tvAcceptStartTime.text=currentItem.startTime
        holder.tvAcceptEndTime.text=currentItem.endTime

        holder.btnDelete.setOnClickListener {
            listener.onItemClickDelete(currentItem.sessionID!!)
        }
        holder.itemView.setOnClickListener{
            listener.onItemClickHostContent(currentItem.sessionID!!,currentItem.sessionName!!,currentItem.details!!,currentItem.date!!,currentItem.startTime!!,currentItem.endTime!!)
        }

    }

    override fun getItemCount(): Int {
        return sessionList.size
    }

    fun setFilteredList(sessionList: List<StudySessionData>) {
        this.sessionList = sessionList
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onItemClickDelete(sessionID: String)
        fun onItemClickHostContent(sessionID:String, sessionName:String, details:String, date:String, startTime:String, endTime:String)
    }
}