package com.example.studybuddy.Data

data class UserStudySession(val userStudySessionID:String?=null,val userID:String?=null, val sessionID:String?=null,val status:String?=null)
