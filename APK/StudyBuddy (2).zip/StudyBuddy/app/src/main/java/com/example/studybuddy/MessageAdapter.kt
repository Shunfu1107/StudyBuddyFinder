package com.example.studybuddy

import android.app.AlertDialog
import android.app.Dialog
import android.content.ContentValues
import android.content.ContentValues.TAG
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MessageAdapter(
    private var messages: List<Message>,
    private val longClickListener: MessageItemLongClickListener
) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    interface MessageItemLongClickListener {
        fun onItemLongClick(message: Message)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messages[position]
        holder.bind(message)
        holder.itemView.setOnLongClickListener {
            longClickListener.onItemLongClick(message)
            true
        }
    }

    override fun getItemCount(): Int {
        return messages.size
    }

    fun updateMessages(newMessages: List<Message>) {
        messages = newMessages
        notifyDataSetChanged()
    }

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val messageTextSender: TextView = itemView.findViewById(R.id.textMessageSender)
        private val messageTextReceiver: TextView = itemView.findViewById(R.id.textMessageReceiver)
        private val messageSender: View = itemView.findViewById(R.id.messageSender)
        private val messageReceiver: View = itemView.findViewById(R.id.messageReceiver)
        private val imgSender: ImageView = itemView.findViewById(R.id.imageViewSender)
        private val imgReceiver: ImageView = itemView.findViewById(R.id.imageViewReceiver)
        private val tvMsgDatetime: TextView = itemView.findViewById(R.id.tvMsgDatetime)
        private val sendername: TextView = itemView.findViewById(R.id.senderName)
        private val receivername: TextView = itemView.findViewById(R.id.receiverName)

        init {
            // Set long click listener on the message views
            messageSender.setOnLongClickListener {
                longClickListener.onItemLongClick(messages[adapterPosition])
                true
            }

            messageReceiver.setOnLongClickListener {
                longClickListener.onItemLongClick(messages[adapterPosition])
                true
            }
        }

        fun bind(message: Message) {
            val firebaseAuth = FirebaseAuth.getInstance()
            val currentUser = firebaseAuth.currentUser
            var loggedInUser: String = ""

            if (currentUser != null) {
                // User is signed in
                loggedInUser = currentUser.uid
                // Use userId for further actions
                Log.d("User", "Current user ID: $loggedInUser")
            }

//            val isSentByUser = message.senderId == "1"
            val isSentByUser = message.senderId == loggedInUser
            val hasText = message.chatMessage.isNotBlank()
            val hasImage = message.chatImages.isNotEmpty() && message.chatImages[0].isNotBlank()
            val usersRef = FirebaseDatabase.getInstance().getReference("users")

            if (isSentByUser) {
                messageSender.visibility = View.VISIBLE
                messageReceiver.visibility = View.GONE

                if (hasImage) {
                    imgSender.visibility = View.VISIBLE
                    Glide.with(itemView.context)
                        .load(message.chatImages[0])
                        .into(imgSender)

                    imgSender.setOnClickListener {
                        showZoomableImageDialog(message.chatImages[0])
                    }
                    imgSender.setOnLongClickListener {
                        longClickListener.onItemLongClick(message)
                        true
                    }
                } else {
                    imgSender.visibility = View.GONE
                }

                // Get sender's name from database
                usersRef.child(message.senderId).child("name").addListenerForSingleValueEvent(object :
                    ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        val senderName = dataSnapshot.getValue(String::class.java)
                        // Set the sender's name in your UI
                        sendername.text = "$senderName"
                        sendername.visibility = View.VISIBLE
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        // Getting username failed, log a message
                        Log.w(TAG, "getUser:onCancelled", databaseError.toException())
                    }
                })

                if (hasText) {
                    messageTextSender.text = message.chatMessage
                    messageTextSender.visibility = View.VISIBLE
                    messageTextSender.setOnLongClickListener {
                        longClickListener.onItemLongClick(message)
                        true
                    }
                } else {
                    messageTextSender.visibility = View.GONE
                }

                // Hide the receiver's message text view
                messageTextReceiver.visibility = View.GONE

            } else {
                messageSender.visibility = View.GONE
                messageReceiver.visibility = View.VISIBLE

                if (hasText) {
                    messageTextReceiver.text = message.chatMessage
                    messageTextReceiver.visibility = View.VISIBLE
                    messageTextReceiver.setOnLongClickListener {
                        longClickListener.onItemLongClick(message)
                        true
                    }
                } else {
                    messageTextReceiver.visibility = View.GONE
                }

                if (hasImage) {
                    imgReceiver.visibility = View.VISIBLE
                    Glide.with(itemView.context)
                        .load(message.chatImages[0])
                        .into(imgReceiver)

                    imgReceiver.setOnClickListener {
                        showZoomableImageDialog(message.chatImages[0])
                    }
                    imgReceiver.setOnLongClickListener {
                        longClickListener.onItemLongClick(message)
                        true
                    }
                } else {
                    imgReceiver.visibility = View.GONE
                }

                // Get sender's name from database
                usersRef.child(message.senderId).child("name").addListenerForSingleValueEvent(object :
                    ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        val receiverName = dataSnapshot.getValue(String::class.java)
                        // Set the sender's name in your UI
                        receivername.text = "$receiverName"
                        receivername.visibility = View.VISIBLE
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        // Getting username failed, log a message
                        Log.w(TAG, "getUser:onCancelled", databaseError.toException())
                    }
                })

                // Hide the sender's message text view
                messageTextSender.visibility = View.GONE
            }

            tvMsgDatetime.text = message.timestamp
        }

        private fun showZoomableImageDialog(imageUrl: String) {
            Log.d(ContentValues.TAG, "imgUrl: $imageUrl")
            val dialogView = LayoutInflater.from(itemView.context).inflate(R.layout.zoom_img, null)
            val imageView = dialogView.findViewById<ImageView>(R.id.zoomableImage)
//            val close = dialogView.findViewById<ImageView>(R.id.close)

            Glide.with(itemView.context)
                .load(imageUrl)
//                .centerInside()
                .into(imageView)

            val dialog = AlertDialog.Builder(itemView.context)
                .setView(dialogView)
                .create()

            // Set the dialog to dismiss when clicked outside of the image
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.setCanceledOnTouchOutside(true)

//            // Close the dialog when clicked outside of the image
//            close.setOnClickListener {
//                dialog.dismiss()
//            }

            dialog.show()
        }
    }

}
