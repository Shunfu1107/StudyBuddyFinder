package com.example.studybuddy

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.example.studybuddy.ChatModel
import com.example.studybuddy.R

class ChatAdapter(
    private var chatList: List<ChatModel>,
    private val listener: OnItemClickListener,
    private val longClickListener: OnItemLongClickListener
) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    // Interface to handle item clicks
    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    // Interface to handle item long clicks
    interface OnItemLongClickListener {
        fun onItemLongClick(position: Int)
    }

    inner class ChatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvUsername = itemView.findViewById<TextView>(R.id.tvUsername)
        val tvMessage = itemView.findViewById<TextView>(R.id.tvMessage)
        val tvDatetime = itemView.findViewById<TextView>(R.id.tvDatetime)
        val imgPfp = itemView.findViewById<ImageView>(R.id.imgPfp)
        val imgPin = itemView.findViewById<ImageView>(R.id.imgPin)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.individualchat, parent, false)

        return ChatViewHolder(view)
    }

    fun updateData(newList: List<ChatModel>) {
        chatList = newList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val chat: ChatModel = chatList[position]
        holder.tvUsername.text = chat.getUsername()
        holder.tvMessage.text = chat.getMessage()
        holder.tvDatetime.text = chat.getDatetime()

        // Load image using Glide with circular transformation
        Glide.with(holder.itemView.context)
            .load(chat.getImageUrl())
            .transform(CircleCrop())
            .into(holder.imgPfp)

        // Set visibility of pin icon based on the "pinned" status
        if (chat.getPinned()) {
            holder.imgPin.visibility = View.VISIBLE
        } else {
            holder.imgPin.visibility = View.GONE
        }

        // Set click listener for the whole item view
        holder.itemView.setOnClickListener {
            listener.onItemClick(position)
        }

        holder.itemView.setOnLongClickListener {
            longClickListener.onItemLongClick(position)
            true
        }
    }

    override fun getItemCount(): Int {
        return chatList.size
    }
}