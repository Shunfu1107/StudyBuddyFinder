package com.example.studybuddy

import android.graphics.Typeface
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import java.util.*


import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.Adapter.AcceptSessionAdapter
import com.example.studybuddy.Adapter.NormalSessionAdapter
import com.example.studybuddy.Adapter.PendingSessionAdapter
import com.example.studybuddy.Adapter.UserAdapter
import com.example.studybuddy.Data.StudySessionData
import com.example.studybuddy.Data.User
import com.example.studybuddy.Data.UserStudySession
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Locale


class Search : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private var userList: ArrayList<User> = ArrayList()
    private var adapter: UserAdapter = UserAdapter(ArrayList())
    private lateinit var searchViewSearch: SearchView
    private val userID = "1"
    private lateinit var dbRefUser: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_search, container, false);
        val tvBtnUser: TextView = view.findViewById(R.id.tvBtnUser)
        val tvBtnPost: TextView = view.findViewById(R.id.tvBtnPost)
        tvBtnUser.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
        tvBtnUser.setTypeface(null, Typeface.BOLD)

        searchViewSearch = view.findViewById(R.id.searchViewSession)
        dbRefUser = FirebaseDatabase.getInstance().getReference("User")


        tvBtnUser.setOnClickListener() {
            tvBtnUser.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
            tvBtnPost.setTextColor(ContextCompat.getColor(requireContext(), R.color.light_grey))


            tvBtnUser.setTypeface(null, Typeface.BOLD)
            tvBtnPost.setTypeface(null, Typeface.NORMAL)

            recyclerView.visibility = View.VISIBLE

        }
        tvBtnPost.setOnClickListener() {
            tvBtnUser.setTextColor(ContextCompat.getColor(requireContext(), R.color.light_grey))
            tvBtnPost.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))

            tvBtnPost.setTypeface(null, Typeface.BOLD)
            tvBtnUser.setTypeface(null, Typeface.NORMAL)

            recyclerView.visibility = View.GONE
        }


        searchViewSearch.clearFocus()

        recyclerView = view.findViewById(R.id.recyclerviewUser)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(context)
        fetchUserData()



        searchViewSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchViewSearch.clearFocus()
                return false

            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }

        })

        return view
    }


    private fun filterList(query: String?) {

        if (query != null) {
            val filteredList = ArrayList<User>()
            for (i in userList) {
                if (i.username!!.lowercase(Locale.ROOT).contains(query)) {
                    filteredList.add(i)
                }
            }

            if (filteredList.isEmpty()) {
                Toast.makeText(requireContext(), "No Data found", Toast.LENGTH_SHORT).show()
            } else {
                adapter.setFilteredList(filteredList)
            }
        }
    }


    private fun fetchUserData() {
        dbRefUser.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                userList.clear()

                if (snapshot.exists()) {
                    for (userSnap in snapshot.children) {
                        val user = userSnap.getValue(User::class.java)
                        if (user != null && user.userID != userID) {

                            userList.add(user!!)

                        }

                    }
                    adapter =UserAdapter(userList)
                    recyclerView.adapter = adapter


                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }


}