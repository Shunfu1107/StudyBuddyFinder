package com.example.studybuddy

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.studybuddy.R
import com.example.studybuddy.User

class UserAdapter(
    private val context: Context,
    private var userList: ArrayList<User>,
    private val onUserClickListener: (String) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.individualuser, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.bind(user)
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    fun filterList(filteredUsers: ArrayList<User>) {
        userList = filteredUsers
        notifyDataSetChanged()
    }

    inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val image: ImageView = itemView.findViewById(R.id.imgPfp)
        private val usernameTextView: TextView = itemView.findViewById(R.id.tvUsername)

        fun bind(user: User) {
            itemView.apply {
                usernameTextView.text = user.username
                // Load image using Glide
                Glide.with(itemView)
                    .load(user.profilePicURL)
                    .circleCrop()
                    .placeholder(R.drawable.defprofile) // Placeholder image
                    .error(R.drawable.defprofile) // Error image
                    .into(image)

                // Set click listener
                setOnClickListener { onUserClickListener.invoke(user.userID) }
            }
        }
    }
}
