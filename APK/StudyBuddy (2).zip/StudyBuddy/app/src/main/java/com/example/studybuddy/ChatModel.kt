package com.example.studybuddy

class ChatModel(
    private val chatID: String,
    private val receiverID: String,
    private val groupName: String, // For group chats
    private var message: String,
    private var datetime: String,
    private var imageUrl: String,
    private var username: String,
    private var pinned: Boolean
) {

    fun getChatId(): String {
        return chatID
    }

    fun getGroupName(): String {
        return groupName
    }

    fun getUsername(): String {
        return username
    }

    fun setUsername(username: String) {
        this.username = username
    }

    fun getMessage(): String {
        return message
    }

    fun setMessage(message: String) {
        this.message = message
    }

    fun getDatetime(): String {
        return datetime
    }

    fun setDatetime(datetime: String) {
        this.datetime = datetime
    }

    fun getImageUrl(): String {
        return imageUrl
    }

    fun setImageUrl(imageUrl: String) {
        this.imageUrl = imageUrl
    }

    fun getReceiverId(): String {
        return receiverID
    }

    fun getPinned(): Boolean {
        return pinned
    }

    fun setPinned(isPinned: Boolean) {
        pinned = isPinned
    }
}
