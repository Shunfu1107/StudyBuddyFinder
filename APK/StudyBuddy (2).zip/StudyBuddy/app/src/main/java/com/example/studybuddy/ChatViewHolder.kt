package com.example.studybuddy

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.NavController
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.ChatMenuDirections
import com.example.studybuddy.R

class ChatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    var imgPfp: ImageView
    var tvUsername: TextView
    var tvMessage: TextView
    var tvDatetime: TextView

    init {
        imgPfp = itemView.findViewById<ImageView>(R.id.imgPfp)
        tvUsername = itemView.findViewById<TextView>(R.id.tvUsername)
        tvMessage = itemView.findViewById<TextView>(R.id.tvMessage)
        tvDatetime = itemView.findViewById<TextView>(R.id.tvDatetime)

    }
}
