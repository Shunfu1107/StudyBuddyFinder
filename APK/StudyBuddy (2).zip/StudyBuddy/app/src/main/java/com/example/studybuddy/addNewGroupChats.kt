package com.example.studybuddy

import android.app.Activity
import android.content.ContentResolver
import android.content.ContentValues.TAG
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.R
import com.google.android.gms.tasks.Task
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import java.io.IOException

class addNewGroupChats : Fragment() {

    private lateinit var loggedInUser: String
    private lateinit var userAdapter: UserAdapter
    private lateinit var userList: ArrayList<User>
    private lateinit var firestore: FirebaseFirestore
    private lateinit var chatDatabase: FirebaseDatabase
    private lateinit var selectedMembers: ArrayList<User>
    private lateinit var memberAdapter: MemberSelectionAdapter

    private val PICK_IMAGE_REQUEST = 71
    private var filePath: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loggedInUser = arguments?.getString("loginuserId") ?: ""
        Log.d(TAG, "LoggedInUserId: $loggedInUser")
        firestore = FirebaseFirestore.getInstance()
        chatDatabase = FirebaseDatabase.getInstance()

        fetchUsersFromFirebase() // Fetch users from Firebase
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_add_new_group_chats, container, false)
        val title: TextView = view.findViewById(R.id.toolbar_title)
        title.text = "New Group Chat"

        // Find the search EditText
        val searchView = view.findViewById<androidx.appcompat.widget.SearchView>(R.id.search2)

        // Set query listener for SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Filter the user list based on the search query
                filterUsers(newText.orEmpty())
                return true
            }
        })

        val imageView = view.findViewById<ImageView>(R.id.imageView2)

        imageView.setOnClickListener {
            launchGallery()
        }

        // Find the back button
        val backButton = view.findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            // Navigate to the ChatDetailsFragment using the action
            val action = addNewGroupChatsDirections.actionAddNewGroupChatsToChatMenu2()
            findNavController().navigate(action)
        }

        // Initialize RecyclerView
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView2)
        recyclerView.layoutManager = LinearLayoutManager(context)
        userList = ArrayList()
        userAdapter = UserAdapter(requireContext(), userList) { userId: String ->
            val user = userList.find { it.userID == userId }
            user?.let {
                // Handle item click
                if (selectedMembers.contains(it)) {
                    selectedMembers.remove(it) // Deselect the member
                } else {
                    selectedMembers.add(it) // Select the member
                }
                updateMemberView()
            }
        }
        recyclerView.adapter = userAdapter

        // Initialize selected members RecyclerView
        val memberRecyclerView = view.findViewById<RecyclerView>(R.id.memberView)
        memberRecyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        selectedMembers = ArrayList()
        memberAdapter = MemberSelectionAdapter(requireContext(), selectedMembers) { user ->
            // Handle click on selected member item
            selectedMembers.remove(user)
            updateMemberView()
        }
        memberRecyclerView.adapter = memberAdapter

        // Find the create button
        val createButton = view.findViewById<ImageButton>(R.id.fabNext)
        createButton.setOnClickListener {
            val groupName =
                view.findViewById<EditText>(R.id.groupNameEditText).text.toString().trim()

            // Check if group name is empty
            if (groupName.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter a group name", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            // Get selected member IDs
            val selectedMemberIDs = selectedMembers.map { it.userID }

            // Check if image is selected
            val defaultImageResourceId = R.drawable.grouppfp
            val groupImageURL: Uri = filePath ?: Uri.parse(
                ContentResolver.SCHEME_ANDROID_RESOURCE + "://" +
                        requireContext().resources.getResourcePackageName(defaultImageResourceId) + '/' +
                        requireContext().resources.getResourceTypeName(defaultImageResourceId) + '/' +
                        requireContext().resources.getResourceEntryName(defaultImageResourceId)
            )

            // Create group chat
            createGroupChat(groupName, groupImageURL, selectedMembers.map { it.userID })
        }

        return view
    }

    private fun updateMemberView() {
        val memberTextView = view?.findViewById<TextView>(R.id.tvMember)
        memberTextView?.text = selectedMembers.size.toString()
        memberAdapter.notifyDataSetChanged()
    }

    private fun launchGallery() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST)
    }

    // Function to filter user list based on the search query
    private fun filterUsers(query: String) {
        val filteredList = ArrayList<User>()
        for (user in userList) {
            if (user.username.toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(user)
            }
        }
        Log.d("Filtered User List", filteredList.toString()) // Add this line to log filtered list
        // Update the RecyclerView adapter with the filtered list
        userAdapter.filterList(filteredList)
    }

    private fun uploadImage(imageUri: Uri): Task<Uri> {
        val storageRef = Firebase.storage.reference
        val imageRef = storageRef.child("group_chat/${imageUri.lastPathSegment}")

        // Upload image to Firebase Storage
        return imageRef.putFile(imageUri)
            .continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                imageRef.downloadUrl
            }
    }

    private fun createGroupChat(groupName: String, imageUri: Uri?, members: List<String>) {
        // Add logged in user to the list of selected members
        val selectedMembersWithLoggedInUser = members.toMutableList().apply {
            add(loggedInUser)
        }

        imageUri?.let { uri ->
            uploadImage(uri)
                .addOnSuccessListener { downloadUri ->
                    val groupImageURL = downloadUri.toString()
                    saveGroupChatToDatabase(groupName, groupImageURL, selectedMembersWithLoggedInUser)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Error uploading image: ", e)
                    Toast.makeText(requireContext(), "Error uploading image", Toast.LENGTH_SHORT)
                        .show()
                }
        } ?: run {
            val defaultImageResourceId = R.drawable.grouppfp
            val groupImageURL =
                Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + requireContext().resources.getResourcePackageName(
                    defaultImageResourceId
                ) + '/' + requireContext().resources.getResourceTypeName(defaultImageResourceId) + '/' + requireContext().resources.getResourceEntryName(
                    defaultImageResourceId
                ))

            saveGroupChatToDatabase(groupName, groupImageURL.toString(), selectedMembersWithLoggedInUser)
        }
    }

    private fun saveGroupChatToDatabase(groupName: String, groupImageURL: String, members: List<String>) {
        val newGroupChatRef = chatDatabase.reference.child("Chats").push()
        val groupChatId = newGroupChatRef.key ?: ""

        newGroupChatRef.setValue(
            GroupChat(
                chatID = groupChatId,
                groupName = groupName,
                groupImageUrl = groupImageURL,
                members = members,
                lastMessage = "", // Last message
                lastMsgDateTime = "", // Last message datetime
                pinned = false, // Pinned
                admin = loggedInUser // Set the admin user ID
            )
        ).addOnSuccessListener {
            // Navigate to the new group chat
            val action = addNewGroupChatsDirections.actionAddNewGroupChatsToChatMenu2()
            findNavController().navigate(action)
//            navigateToGroupChatDetails(groupChatId, groupName, groupImageURL)
        }.addOnFailureListener { exception ->
            Log.e(TAG, "Error creating group chat: ", exception)
            Toast.makeText(requireContext(), "Error creating group chat", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchUsersFromFirebase() {
        val usersRef = FirebaseDatabase.getInstance().getReference("users")

        usersRef.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val userId = snapshot.key
                val username = snapshot.child("name").getValue(String::class.java) ?: ""
                val imageUrl = snapshot.child("photoUrl").getValue(String::class.java) ?: ""
                if (userId != loggedInUser) {
                    userList.add(User(userId ?: "", username, imageUrl))
                    userAdapter.notifyDataSetChanged()
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                val userId = snapshot.key
                val username = snapshot.child("name").getValue(String::class.java) ?: ""
                val imageUrl = snapshot.child("photoUrl").getValue(String::class.java) ?: ""
                val userIndex = userList.indexOfFirst { it.userID == userId }
                if (userIndex != -1) {
                    userList[userIndex] =
                        userList[userIndex].copy(username = username, profilePicURL = imageUrl)
                    userAdapter.notifyItemChanged(userIndex)
                }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val userId = snapshot.key
                val userIndex = userList.indexOfFirst { it.userID == userId }
                if (userIndex != -1) {
                    userList.removeAt(userIndex)
                    userAdapter.notifyItemRemoved(userIndex)
                }
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                // Handle moved data if needed
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle errors
                Log.e(TAG, "Error fetching users", error.toException())
            }
        })
    }

//    private fun navigateToGroupChatDetails(groupChatId: String, groupName: String, imageUrl: String) {
//        // Assuming you have a NavDirections action to navigate to the group chat details
//        val action = addNewGroupChatsDirections.actionAddNewGroupChatsToGroupDetails(
//            groupChatId,
//            loggedInUser,
//            groupName,
//            imageUrl
//        )
//        findNavController().navigate(action)
//    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            filePath = data.data
            try {
                val bitmap =
                    MediaStore.Images.Media.getBitmap(requireActivity().contentResolver, filePath)
                val imageView = view?.findViewById<ImageView>(R.id.imageView2)
                imageView?.setImageBitmap(bitmap)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }
}