package com.example.studybuddy.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.Data.StudySessionData
import com.example.studybuddy.R

class PendingSessionAdapter(private var sessionList: List<StudySessionData>, private val listener: PendingSessionAdapter.OnItemClickListener) : RecyclerView.Adapter
<PendingSessionAdapter.MyViewHolder>(){
    class MyViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){
        val tvSessionName : TextView = itemView.findViewById(R.id.tvPendingSessionName)
        val tvDetails : TextView = itemView.findViewById(R.id.tvPendingDetails)
        val tvStartTime : TextView = itemView.findViewById(R.id.tvPendingStartTime)
        val tvDate : TextView = itemView.findViewById(R.id.tvPendingDate)
        val tvEndTime : TextView = itemView.findViewById(R.id.tvPendingEndTime)
        val btnDecline : Button = itemView.findViewById(R.id.btnDecline)
        val btnAccept : Button = itemView.findViewById(R.id.btnAccept)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate( R.layout.session_pending, parent, false )
        return MyViewHolder(itemView)
    }
    override fun getItemCount(): Int {
        return sessionList.size
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = sessionList[position]
        holder.tvSessionName.text = currentItem.sessionName
        holder.tvDetails.text=currentItem.details
        holder.tvDate.text=currentItem.date
        holder.tvStartTime.text=currentItem.startTime
        holder.tvEndTime.text=currentItem.endTime

        holder.btnDecline.setOnClickListener {
            listener.onItemClickDecline(currentItem.sessionID!!)
        }
        holder.btnAccept.setOnClickListener {
            listener.onItemClickAccept(currentItem.sessionID!!)
        }
    }
    fun setFilteredList(sessionList: List<StudySessionData>) {
        this.sessionList = sessionList
        notifyDataSetChanged()
    }
    interface OnItemClickListener {
        fun onItemClickDecline(sessionID: String)
        fun onItemClickAccept(sessionID: String)
    }

}