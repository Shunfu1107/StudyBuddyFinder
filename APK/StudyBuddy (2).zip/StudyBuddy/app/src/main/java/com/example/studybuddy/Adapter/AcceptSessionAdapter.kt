package com.example.studybuddy.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.Data.StudySessionData
import com.example.studybuddy.R

class AcceptSessionAdapter(private var sessionList: List<StudySessionData>, private val listener: AcceptSessionAdapter.OnItemClickListener) : RecyclerView.Adapter
<AcceptSessionAdapter.MyViewHolder>() {
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvAcceptSessionName: TextView = itemView.findViewById(R.id.tvAcceptSessionName)
        val tvAcceptDetails: TextView = itemView.findViewById(R.id.tvAcceptDetails)
        val tvAcceptStartTime: TextView = itemView.findViewById(R.id.tvAcceptStartTime)
        val tvAcceptDate: TextView = itemView.findViewById(R.id.tvAcceptDate)
        val tvAcceptEndTime: TextView = itemView.findViewById(R.id.tvAcceptEndTime)
        val btnQuit: Button = itemView.findViewById(R.id.btnQuit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate( R.layout.session_accept, parent, false )
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = sessionList[position]
        holder.tvAcceptSessionName.text = currentItem.sessionName
        holder.tvAcceptDetails.text=currentItem.details
        holder.tvAcceptDate.text=currentItem.date
        holder.tvAcceptStartTime.text=currentItem.startTime
        holder.tvAcceptEndTime.text=currentItem.endTime

        holder.btnQuit.setOnClickListener {
            listener.onItemClickQuit(currentItem.sessionID!!)
        }
        holder.itemView.setOnClickListener{
            listener.onItemClickContent(currentItem.sessionID!!,currentItem.sessionName!!,currentItem.details!!,currentItem.date!!,currentItem.startTime!!,currentItem.endTime!!)
        }
    }

    override fun getItemCount(): Int {
        return sessionList.size
    }

    fun setFilteredList(sessionList: List<StudySessionData>) {
        this.sessionList = sessionList
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onItemClickQuit(sessionID: String)
        fun onItemClickContent(sessionID:String, sessionName:String, details:String, date:String, startTime:String, endTime:String)

    }
}