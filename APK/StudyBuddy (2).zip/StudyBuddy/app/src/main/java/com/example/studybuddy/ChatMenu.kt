package com.example.studybuddy

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.ChatDetails
import com.example.studybuddy.ChatModel
import com.example.studybuddy.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import androidx.lifecycle.LiveData

class ChatMenu : Fragment(), ChatAdapter.OnItemClickListener, ChatAdapter.OnItemLongClickListener {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ChatAdapter

    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Retain the fragment
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_chatmenu, container, false)
        recyclerView = view.findViewById(R.id.chatsView)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize RecyclerView adapter
        adapter = ChatAdapter(emptyList(), this, this)
        recyclerView.adapter = adapter

        // Observe chat list LiveData
        viewModel.chatList.observe(viewLifecycleOwner, Observer { newChatList ->
            adapter.updateData(newChatList)
            recyclerView.scrollToPosition(newChatList.size - 1)
        })

        // Fetch chat list only if savedInstanceState is null
        if (savedInstanceState == null) {
            viewModel.fetchChatList()
        }

        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        var loggedInUser: String = ""

        if (currentUser != null) {
            // User is signed in
            loggedInUser = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $loggedInUser")
        }

//        var loggedInUser: String = "KC99FVvo2hRlC7MbJX2P9E3lRh13"

        // Set OnClickListener to the FloatingActionButton
        view.findViewById<ImageButton>(R.id.fabAdd).setOnClickListener {
            // Navigate to the add new chat page
            val action = ChatMenuDirections.actionChatMenuToAddNewChats(loggedInUser)
            findNavController().navigate(action)
        }
    }

    override fun onItemClick(position: Int) {
        val chatList = viewModel.chatList.value ?: return
        if (position >= 0 && position < chatList.size) {
            val clickedItem = chatList[position]
            val username = clickedItem.getUsername()
            val imgUrl = clickedItem.getImageUrl()
            val receiverId = clickedItem.getReceiverId()
            val chatId = clickedItem.getChatId() // Get the chatId
            val action = ChatMenuDirections.actionChatMenuToChatDetails2(
                username,
                imgUrl,
                receiverId,
                chatId
            ) // Pass chatId as an argument
            findNavController().navigate(action)
        } else {
            Log.e(TAG, "Invalid position: $position")
        }
    }

    override fun onItemLongClick(position: Int) {
        val chatList = viewModel.chatList.value ?: return
        if (position >= 0 && position < chatList.size) {
            val clickedItem = chatList[position]
            val chatId = clickedItem.getChatId()
            val groupName = clickedItem.getGroupName()
            val options = mutableListOf<String>()

            // Check if the chat is pinned
            if (clickedItem.getPinned()) {
                // If pinned, add the option to unpin
                options.add("Unpin Chat")
            } else {
                // If not pinned, add the option to pin
                options.add("Pin Chat")
            }

            // For group chats, user can only pin the chat
            if (groupName.isNullOrEmpty()) {
                options.add("Delete Chat")
            }

            val builder = AlertDialog.Builder(requireContext())
            builder.setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> {
                        // Handle pin/unpin option
                        if (clickedItem.getPinned()) {
                            // Unpin option selected
                            showUnpinConfirmation(chatId)
                        } else {
                            // Pin option selected
                            showPinConfirmation(chatId)
                        }
                    }

                    1 -> {
                        // Delete option selected
                        showDeleteConfirmation(chatId)
                    }
                }
            }
            builder.show()
        } else {
            Log.e(TAG, "Invalid position: $position")
        }
    }

    fun showPinConfirmation(chatId: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to pin this chat?")
            .setCancelable(false)
            .setPositiveButton("Pin") { dialog, id ->
                // Call the ViewModel method to delete the chat
                viewModel.pinChat(chatId, true)
            }
            .setNegativeButton("Cancel") { dialog, id ->
                // Dismiss the dialog if cancel is clicked
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    fun showUnpinConfirmation(chatId: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to pin this chat?")
            .setCancelable(false)
            .setPositiveButton("Unpin") { dialog, id ->
                // Call the ViewModel method to delete the chat
                viewModel.unpinChat(chatId)
            }
            .setNegativeButton("Cancel") { dialog, id ->
                // Dismiss the dialog if cancel is clicked
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    fun showDeleteConfirmation(chatId: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Deletion of chat could affect both users. Are you sure you want to delete this chat?")
            .setCancelable(false)
            .setPositiveButton("Delete") { dialog, id ->
                // Call the ViewModel method to delete the chat
                viewModel.deleteChat(chatId)
            }
            .setNegativeButton("Cancel") { dialog, id ->
                // Dismiss the dialog if cancel is clicked
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    companion object {
        private const val TAG = "ChatMenu"
    }
}