package com.example.chatmodule

data class Chat (
    val chatID: String,
    val userID: String,  //logged in userId
    val receiverID: String, //chat userId that was clicked
    val lastMessage: String,
    val lastMsgDateTime: String,
    val pinned: Boolean
)