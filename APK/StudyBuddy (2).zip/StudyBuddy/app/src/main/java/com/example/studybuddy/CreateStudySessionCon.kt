package com.example.studybuddy

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.Adapter.UserAddAdapter
import com.example.studybuddy.Data.StudySessionData
import com.example.studybuddy.Data.UserStudySession
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.util.ArrayList
import java.util.Locale
import java.util.UUID


class CreateStudySessionCon : Fragment(), UserAddAdapter.OnItemClickListener {
    private lateinit var recyclerView: RecyclerView
    private var userList: ArrayList<User> = ArrayList()
    private var adapter: UserAddAdapter = UserAddAdapter(ArrayList(), this@CreateStudySessionCon)
    private lateinit var searchViewAdd: SearchView
    private val userID = "1"
    private lateinit var dbRefUser: DatabaseReference
    private var userAddList: ArrayList<String> = ArrayList()
    private lateinit var dbRefUserStudySession: DatabaseReference
    private lateinit var dbRefSession: DatabaseReference

    var sessionID:String = ""
    var sessionName:String = ""
    var sessionDetails :String = ""
    var sessionDate:String = ""
    var sessionStartTime :String = ""
    var sessionEndTime :String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_create_study_session_con, container, false)
        dbRefUser = FirebaseDatabase.getInstance().getReference("User")
        dbRefUserStudySession = FirebaseDatabase.getInstance().getReference("UserStudySession")
        dbRefSession = FirebaseDatabase.getInstance().getReference("StudySession")

        val btnCreate: Button = view.findViewById(R.id.btnCreate)

        // Receive arguments passed from the previous fragment
        sessionID = arguments?.getString("sessionID") ?: ""
         sessionName = arguments?.getString("sessionName") ?: ""
        sessionDetails = arguments?.getString("sessionDetails") ?: ""
         sessionDate = arguments?.getString("sessionDate") ?: ""
        sessionStartTime = arguments?.getString("sessionStartTime") ?: ""
        sessionEndTime = arguments?.getString("sessionEndTime") ?: ""
        //testing purpose
        val tvTest: TextView = view.findViewById(R.id.tvTest)
        tvTest.text = sessionName

        searchViewAdd = view.findViewById(R.id.searchViewAdd)
        searchViewAdd.clearFocus()
        recyclerView = view.findViewById(R.id.recyclerviewUserAdd)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(context)
        fetchUserData()



        searchViewAdd.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchViewAdd.clearFocus()
                return false

            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }

        })

        btnCreate.setOnClickListener {

            CoroutineScope(Dispatchers.Main).launch {
                // Execute addSessionToDB() and addUserSessionToDB() concurrently
                val job1 = async { addSessionToDB() }
                val job2 = async { addUserSessionToDB() }

                // Wait for both jobs to complete
                job1.await()
                job2.await()

                // After both jobs are completed, navigate to the new page
                val action =
                    CreateStudySessionConDirections.actionCreateStudySessionConToStudySession()
                findNavController().navigate(action)
            }
        }

        return view
    }

    private fun filterList(query: String?) {

        if (query != null) {
            val filteredList = ArrayList<User>()
            for (i in userList) {
                if (i.username!!.lowercase(Locale.ROOT).contains(query)) {
                    filteredList.add(i)
                }
            }

            if (filteredList.isEmpty()) {
                Toast.makeText(requireContext(), "No Data found", Toast.LENGTH_SHORT).show()
            } else {
                adapter.setFilteredList(filteredList)
            }
        }
    }

    private fun fetchUserData() {
        dbRefUser.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                userList.clear()

                if (snapshot.exists()) {
                    for (userSnap in snapshot.children) {
                        val user = userSnap.getValue(User::class.java)
                        if (user != null && user.userID != userID) {

                            userList.add(user!!)

                        }

                    }
                    recyclerView.adapter = UserAddAdapter(userList, this@CreateStudySessionCon)


                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    override fun onItemClickADD(userID: String) {
        userAddList.add(userID)
    }

    private fun addSessionToDB() {

        val studySession = StudySessionData(
            sessionID,
            sessionName,
            sessionDetails,
            sessionDate,
            sessionStartTime,
            sessionEndTime
        )
        if (studySession.sessionID != null) {
            dbRefSession.child(studySession.sessionID).setValue(studySession)
                .addOnCompleteListener {
                    Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {
                    Toast.makeText(
                        requireContext(),
                        "Error ${it.toString()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }
    }

    private fun addUserSessionToDB() {
        var fail = false
        val userSessionHostid = UUID.randomUUID()
        val userStudySessionHost = UserStudySession(userSessionHostid.toString(), userID, sessionID, "host")
        dbRefUserStudySession.child(userStudySessionHost.userStudySessionID!!).setValue(userStudySessionHost)
        if (userAddList != null && !userAddList.isEmpty()) {
            for (item in userAddList) {
                val id = UUID.randomUUID()
                val userStudySession =
                    UserStudySession(id.toString(), item.toString(), sessionID, "pending")
                dbRefUserStudySession.child(userStudySession.userStudySessionID!!)
                    .setValue(userStudySession).addOnFailureListener {
                        fail = true
                    }
            }

            if (fail == false) {
                Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(
                    requireContext(),
                    "Error",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }


}


