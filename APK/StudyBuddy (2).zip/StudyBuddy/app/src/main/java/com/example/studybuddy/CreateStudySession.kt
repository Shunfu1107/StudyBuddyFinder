package com.example.studybuddy

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.text.InputType
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.studybuddy.Data.StudySessionData
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.UUID


class CreateStudySession : Fragment(), DatePickerDialog.OnDateSetListener {
    private lateinit var etvSessionDate: EditText
    private lateinit var date: Date
    private lateinit var etvSessionStartTime: EditText
    private lateinit var etvSessionEndTime: EditText

    private lateinit var dbRef: DatabaseReference


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_create_study_session, container, false);
        val btnNext: Button = view.findViewById(R.id.btnNext)

        val etvSessionName: EditText = view.findViewById(R.id.etvSessionName)
        val etvSessionDetails: EditText = view.findViewById(R.id.etvSessionDetails)

        //date picker part
        etvSessionDate = view.findViewById(R.id.etvSessionDate)
        val ivCalendar: ImageView = view.findViewById<ImageView>(R.id.ivCalendar)
        etvSessionDate.inputType = InputType.TYPE_NULL
        date = Calendar.getInstance().time

        //time picker part
        etvSessionStartTime = view.findViewById(R.id.etvSessionStartTime)
        val ivClockStart: ImageView = view.findViewById(R.id.ivClockStart)
        etvSessionEndTime = view.findViewById(R.id.etvSessionEndTime)
        val ivClockEnd: ImageView = view.findViewById(R.id.ivClockEnd)

        //firebase
        dbRef = FirebaseDatabase.getInstance().getReference("StudySession")

        ivCalendar.setOnClickListener() {
            val calendar = Calendar.getInstance()
            calendar.time = date
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            DatePickerDialog(requireContext(), this, year, month, day).show()
        }

        ivClockStart.setOnClickListener() {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                etvSessionStartTime.setText(SimpleDateFormat("HH:mm").format(cal.time))
            }
            TimePickerDialog(
                requireContext(),
                timeSetListener,
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                true
            ).show()
        }
        ivClockEnd.setOnClickListener() {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                etvSessionEndTime.setText(SimpleDateFormat("HH:mm").format(cal.time))
            }
            TimePickerDialog(
                requireContext(),
                timeSetListener,
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                true
            ).show()
        }

//        btnNext.setOnClickListener {
//
//            val studySession = StudySessionData(id.toString(),etvSessionName.text.toString(),etvSessionDetails.text.toString(),etvSessionDate.text.toString(),etvSessionStartTime.text.toString(),etvSessionEndTime.text.toString())
//            if(studySession.sessionID!=null) {
//                dbRef.child(studySession.sessionID).setValue(studySession)
//                    .addOnCompleteListener {
//                        Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
//                    }
//                    .addOnFailureListener {
//                        Toast.makeText(
//                            requireContext(),
//                            "Error ${it.toString()}",
//                            Toast.LENGTH_LONG
//                        ).show()
//                    }
//            }
//
//        }
        //btn to next page
        btnNext.setOnClickListener {
            val action =
                CreateStudySessionDirections.actionCreateStudySessionToCreateStudySessionCon(
                     UUID.randomUUID().toString(),
                    etvSessionName.text.toString(),
                    etvSessionDetails.text.toString(),
                    etvSessionDate.text.toString(),
                    etvSessionStartTime.text.toString(),
                    etvSessionEndTime.text.toString()
                )
            findNavController().navigate(action)
        }



        return view
    }


    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        etvSessionDate.setText("$dayOfMonth/$month/$year")
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
        date = calendar.time
    }


}