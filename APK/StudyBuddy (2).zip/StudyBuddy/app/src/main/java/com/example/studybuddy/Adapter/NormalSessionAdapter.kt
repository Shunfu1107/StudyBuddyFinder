package com.example.studybuddy.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.studybuddy.Data.StudySessionData
import com.example.studybuddy.R

class NormalSessionAdapter (private var sessionList: List<StudySessionData>, private val listener: OnItemClickListener
) : RecyclerView.Adapter
<NormalSessionAdapter.MyViewHolder>() {

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSessionName: TextView = itemView.findViewById(R.id.tvNormalSessionName)
        val tvDetails: TextView = itemView.findViewById(R.id.tvNormalDetails)
        val tvStartTime: TextView = itemView.findViewById(R.id.tvNormalStartTime)
        val tvDate: TextView = itemView.findViewById(R.id.tvNormalDate)
        val tvEndTime: TextView = itemView.findViewById(R.id.tvNormalEndTime)
        val btnJoin: Button = itemView.findViewById(R.id.btnJoin)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate( R.layout.session_normal, parent, false )
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = sessionList[position]
        holder.tvSessionName.text = currentItem.sessionName
        holder.tvDetails.text=currentItem.details
        holder.tvDate.text=currentItem.date
        holder.tvStartTime.text=currentItem.startTime
        holder.tvEndTime.text=currentItem.endTime

        holder.btnJoin.setOnClickListener {
           listener.onItemClick(currentItem.sessionID!!)
        }
    }

    override fun getItemCount(): Int {
        return sessionList.size
    }

    fun setFilteredList(sessionList: List<StudySessionData>) {
        this.sessionList = sessionList
        notifyDataSetChanged()
    }
    interface OnItemClickListener {
        fun onItemClick(sessionId: String)
    }

}