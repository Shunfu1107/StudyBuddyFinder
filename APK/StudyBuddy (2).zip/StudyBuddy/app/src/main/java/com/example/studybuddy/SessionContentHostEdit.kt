package com.example.studybuddy

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.Date

class SessionContentHostEdit : Fragment() {

    private lateinit var sessionContentID: String
    private lateinit var dbRefSessionContent: DatabaseReference
    private lateinit var sessionID:String
    private lateinit var sessionName: String
    private lateinit var details: String
    private lateinit var startTime: String
    private lateinit var date: String
    private lateinit var endTime: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_session_content_host_edit, container, false)
        val btnEditSessionContent: Button = view.findViewById(R.id.btnEditSessionContent)
        val textAreaEditSessionContent:TextView = view.findViewById(R.id.textAreaEditSessionContent)
        sessionContentID = arguments?.getString("sessionContentID") ?: ""
        sessionID = arguments?.getString("sessionID") ?: ""

        sessionName= arguments?.getString("sessionName") ?: ""
        details = arguments?.getString("sessionDetails") ?: ""
        date = arguments?.getString("sessionDate") ?: ""
        startTime = arguments?.getString("sessionStartTime") ?: ""
        endTime = arguments?.getString("sessionEndTime") ?: ""

        dbRefSessionContent = FirebaseDatabase.getInstance().getReference("SessionContent")

        btnEditSessionContent.setOnClickListener {
            var editdate: Date
            editdate = Date()
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm")
            val formattedDate = dateFormat.format(editdate)
                    dbRefSessionContent.child(sessionContentID!!).child("sessionContent")
                        .setValue(textAreaEditSessionContent.text.toString()).addOnCompleteListener {
                            Toast.makeText(requireContext(), "Edited", Toast.LENGTH_LONG).show()
                        }
            dbRefSessionContent.child(sessionContentID!!).child("date")
                .setValue(formattedDate.toString()+"(Edited)").addOnCompleteListener {
                    Toast.makeText(requireContext(), "Date Edited Updated", Toast.LENGTH_LONG).show()
                }
            val action = SessionContentHostEditDirections.actionSessionContentHostEditToSessionContentHost(sessionID,sessionName, details, date, startTime, endTime)
            findNavController().navigate(action)
                }




        return view
    }


}