package com.example.studybuddy

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.studybuddy.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    //test data input to firebase
//    private lateinit var dbRef : DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNav.setOnItemSelectedListener {
            when(it.itemId){
                R.id.nav_search -> replaceFragment(Search())
                R.id.nav_studysession -> replaceFragment(StudySession())
                R.id.nav_chat->replaceFragment(ChatMenu())
            else->{

            }
            }
            true
        }
        //test data input to firebase
//        dbRef = FirebaseDatabase.getInstance().getReference("Person")
//        val person = Person("P001","John", "0123456798")
//        dbRef.child(person.id).setValue(person)
//            .addOnCompleteListener{
//                Toast.makeText(this, "Data saved", Toast.LENGTH_LONG).show()
//            }
//            .addOnFailureListener{
//                Toast.makeText(this, "Error ${it.toString()}", Toast.LENGTH_LONG).show()
//            }
    }

    private fun replaceFragment(fragment: Fragment){
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragmentContainerView2,fragment)
        fragmentTransaction.commit()
    }
}