package com.example.studybuddy.Data

data class SessionContent(
    val sessionContentID: String?=null,
    val sessionID: String?=null,
    val sessionContent:String?=null,
    val pdfPath: String?=null,
    val date:String?=null,
    val pdfuri:String?=null
)
