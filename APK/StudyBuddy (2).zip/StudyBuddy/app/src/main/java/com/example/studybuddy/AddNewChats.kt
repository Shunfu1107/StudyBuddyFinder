package com.example.studybuddy

import android.content.ContentValues.TAG
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.chatmodule.Chat
import com.example.studybuddy.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore

class AddNewChats : Fragment() {

    private lateinit var loggedInUser: String
    private lateinit var userAdapter: UserAdapter
    private lateinit var userList: ArrayList<User>
    private lateinit var firestore: FirebaseFirestore
    private lateinit var chatDatabase: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loggedInUser = arguments?.getString("userId") ?: ""
        Log.d(TAG, "LoggedInUserId: $loggedInUser")
        firestore = FirebaseFirestore.getInstance()
        userList = ArrayList()
        userAdapter = UserAdapter(requireContext(), userList) { userId ->
            checkChatAndNavigate(userId)
        }

        chatDatabase = FirebaseDatabase.getInstance()

        fetchUsersFromFirebase() // Fetch users from Firebase
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_new_chats, container, false)

        // Initialize RecyclerView and Adapter
        val recyclerView = view.findViewById<RecyclerView>(R.id.usersView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = userAdapter // Set adapter here

        // Find the search EditText
        val searchView = view.findViewById<androidx.appcompat.widget.SearchView>(R.id.search)

        // Set query listener for SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Filter the user list based on the search query
                filterUsers(newText.orEmpty())
                return true
            }
        })

        // Find the back button
        val backButton = view.findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            // Navigate to the ChatDetailsFragment using the action
            val action = AddNewChatsDirections.actionAddNewChatsToChatMenu2()
            findNavController().navigate(action)
        }

        // Find the group chat button
        val groupChatButton = view.findViewById<View>(R.id.grpchatbtn)
        groupChatButton.setOnClickListener {
            // Navigate to the create group page
            val action = AddNewChatsDirections.actionAddNewChatsToAddNewGroupChats(loggedInUser)
            findNavController().navigate(action)
        }

        return view
    }

    private fun fetchUsersFromFirebase() {
        val usersRef = FirebaseDatabase.getInstance().getReference("users")

        usersRef.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val userId = snapshot.key
                val username = snapshot.child("name").getValue(String::class.java) ?: ""
                val imageUrl = snapshot.child("photoUrl").getValue(String::class.java) ?: ""
                if (userId != loggedInUser) {
                    userList.add(User(userId ?: "", username, imageUrl))
                    userAdapter.notifyDataSetChanged()
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                val userId = snapshot.key
                val username = snapshot.child("name").getValue(String::class.java) ?: ""
                val imageUrl = snapshot.child("photoUrl").getValue(String::class.java) ?: ""
                val userIndex = userList.indexOfFirst { it.userID == userId }
                if (userIndex != -1) {
                    userList[userIndex] =
                        userList[userIndex].copy(username = username, profilePicURL = imageUrl)
                    userAdapter.notifyItemChanged(userIndex)
                }
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                val userId = snapshot.key
                val userIndex = userList.indexOfFirst { it.userID == userId }
                if (userIndex != -1) {
                    userList.removeAt(userIndex)
                    userAdapter.notifyItemRemoved(userIndex)
                }
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                // Handle moved data if needed
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle errors
                Log.e(TAG, "Error fetching users", error.toException())
            }
        })
    }

    // Function to filter user list based on the search query
    private fun filterUsers(query: String) {
        val filteredList = ArrayList<User>()
        for (user in userList) {
            if (user.username.toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(user)
            }
        }
        Log.d("Filtered User List", filteredList.toString()) // Add this line to log filtered list
        // Update the RecyclerView adapter with the filtered list
        userAdapter.filterList(filteredList)
    }

    private fun checkChatAndNavigate(userId: String) {
        val chatRef = chatDatabase.reference.child("Chats")

        Log.d(TAG, "ChatRef: $chatRef")

        chatRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                var existingChatId = ""
                var existingChatUserId = ""
                var chatExists = false

                Log.d(TAG, "DataSnapshot: $dataSnapshot")
                if (dataSnapshot.exists()) {
                    Log.d(TAG, "DataSnapshot exists")
                    for (chatSnapshot in dataSnapshot.children) {
                        val receiverId = chatSnapshot.child("receiverID").getValue(String::class.java) ?: ""
                        val senderId = chatSnapshot.child("userID").getValue(String::class.java) ?: ""

                        Log.d(TAG, "Sender ID: $senderId, Receiver ID: $receiverId, LoggedInUser: $loggedInUser, UserID: $userId")

                        if ((senderId == loggedInUser && receiverId == userId) ||
                            (senderId == userId && receiverId == loggedInUser)
                        ) {
                            // Chat already exists
                            chatExists = true
                            existingChatId = chatSnapshot.key ?: ""
                            existingChatUserId = if (senderId == loggedInUser) receiverId else senderId
                            break
                        }
                    }

                    if (chatExists) {
                        // Navigate to existing chat
                        Log.d(TAG, "Navigating to existing chat. User ID: $existingChatUserId, Chat ID: $existingChatId")
                        navigateToChatDetails(existingChatUserId, existingChatId)
                    } else {
                        // Create new chat
                        Log.d(TAG, "Creating new chat for user: $userId")
                        createNewChat(userId)
                    }
                } else {
                    Log.d(TAG, "DataSnapshot does not exist")
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e(TAG, "checkChatAndNavigate:onCancelled", databaseError.toException())
            }
        })
    }

    private fun navigateToChatDetails(userId: String, chatId: String) {
        // Fetch username and imageUrl for receiverId
        val usersRef = FirebaseDatabase.getInstance().getReference("users")
        val receiverRef = usersRef.child(userId)

        receiverRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val receiverUsername = dataSnapshot.child("name").getValue(String::class.java) ?: ""
                val receiverImgUrl =
                    dataSnapshot.child("photoUrl").getValue(String::class.java) ?: ""

                val action = AddNewChatsDirections.actionAddNewChatsToChatDetails2(
                    receiverUsername,
                    receiverImgUrl,
                    userId,
                    chatId
                )
                findNavController().navigate(action)
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e(TAG, "Error fetching receiver data", databaseError.toException())
            }
        })
    }

    private fun createNewChat(userId: String) {
        // Create a new chat
        val newChatRef = chatDatabase.reference.child("Chats").push()
        val chatId = newChatRef.key ?: ""

        // Fetch username and imageUrl for receiverId
        val usersRef = FirebaseDatabase.getInstance().getReference("users")

        usersRef.child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val receiverUsername = dataSnapshot.child("name").getValue(String::class.java) ?: ""
                val receiverImgUrl =
                    dataSnapshot.child("photoUrl").getValue(String::class.java) ?: ""

                newChatRef.setValue(
                    Chat(
                        chatId,
                        loggedInUser,
                        userId,
                        "", // Last message
                        "", // Last message datetime
                        false // Pinned
                    )
                ).addOnSuccessListener {
                    val action = AddNewChatsDirections.actionAddNewChatsToChatMenu2()
                    findNavController().navigate(action)
                }.addOnFailureListener { exception ->
                    Log.e(TAG, "Error creating chat: ", exception)
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e(TAG, "Error fetching user details", databaseError.toException())
            }
        })
    }
}

