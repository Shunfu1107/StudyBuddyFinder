package com.example.assignment.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.Data.SessionContent
import com.example.assignment.R

class SessionContentAdapter  (private var sessionContentList: List<SessionContent>) : RecyclerView.Adapter
<SessionContentAdapter.MyViewHolder>(){
    class MyViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){
        val tvContentHostDate: TextView = itemView.findViewById(R.id.tvContentHostDate)
        val tvContentHost: TextView = itemView.findViewById(R.id.tvContentHost)

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate( R.layout.session_content_host_cell, parent, false )
        return MyViewHolder(itemView)
    }
    override fun getItemCount(): Int {
        return sessionContentList.size
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = sessionContentList[position]
        holder.tvContentHostDate.text = currentItem.date
        holder.tvContentHost.text=currentItem.sessionContent


    }


}