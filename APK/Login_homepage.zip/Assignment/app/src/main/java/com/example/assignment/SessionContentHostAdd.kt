package com.example.assignment

import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.navigation.fragment.findNavController
import com.example.assignment.Data.SessionContent
import com.example.assignment.databinding.ActivityMainBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.text.SimpleDateFormat
import java.util.Date
import java.util.UUID

class SessionContentHostAdd : Fragment() {

    private lateinit var dbRefSessionContent: DatabaseReference
    private lateinit var storageRef : StorageReference
    private lateinit var sessionID:String
    private lateinit var textAreaSessionContent: EditText
    private lateinit var contentdate: Date
    private lateinit var sessionName: String
    private lateinit var details: String
    private lateinit var startTime: String
    private lateinit var date: String
    private lateinit var endTime: String
    private var pdfFileUri: Uri? = null
    private var downloaduri:String?=null
    private lateinit var progressBar: ProgressBar
    private lateinit var binding: ActivityMainBinding
private lateinit var PDFName:TextView
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_session_content_host_add, container, false)
        textAreaSessionContent = view.findViewById(R.id.textAreaSessionContent)
        dbRefSessionContent = FirebaseDatabase.getInstance().getReference("SessionContent")
        storageRef = FirebaseStorage.getInstance().reference.child("SessionContentPDF")
        sessionID = arguments?.getString("sessionID") ?: ""
        sessionName= arguments?.getString("sessionName") ?: ""
        details = arguments?.getString("sessionDetails") ?: ""
        date = arguments?.getString("sessionDate") ?: ""
        startTime = arguments?.getString("sessionStartTime") ?: ""
        endTime = arguments?.getString("sessionEndTime") ?: ""

        PDFName = view.findViewById(R.id.fileName1)
        progressBar= view.findViewById(R.id.progressBar)

        val btnPostSessionContent: Button = view.findViewById(R.id.btnPostSessionContent)
        btnPostSessionContent.setOnClickListener {
            addSessionContentToDB()

        }

        val selectPdfButton:Button = view.findViewById(R.id.selectPdfButton)
        selectPdfButton.setOnClickListener {
            launcher.launch("application/pdf")
        }
        val btnUpload:Button = view.findViewById(R.id.btnupload)
        btnUpload.setOnClickListener {
                if (pdfFileUri != null) {
                    uploadPdfFileToFirebase()
                } else {
                    Toast.makeText(requireContext(), "Please select pdf first", Toast.LENGTH_SHORT).show()
                }

        }

        return view
    }

    private fun uploadPdfFileToFirebase() {

        val fileName = PDFName.text.toString()
        val mStorageRef = storageRef.child("$fileName")

        if(fileName!=null){
        pdfFileUri?.let { uri ->
            mStorageRef.putFile(uri).addOnSuccessListener {
                mStorageRef.downloadUrl.addOnCompleteListener {downloadUri ->

                    downloaduri = downloadUri.toString()
                    Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
                }.addOnFailureListener() {
                    Toast.makeText(
                        requireContext(),
                        "Error",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
     }
    }

    private fun addSessionContentToDB() {
        contentdate = Date()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm")
        val formattedDate = dateFormat.format(contentdate)
        val sessionContentid = UUID.randomUUID()
        val sessionContent =
            SessionContent(
                sessionContentid.toString(),
                sessionID,
                textAreaSessionContent.text.toString(),
                PDFName.text.toString(),
                formattedDate.toString(),
                downloaduri

            )
        dbRefSessionContent.child(sessionContentid.toString())
            .setValue(sessionContent).addOnCompleteListener {
                Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
            }.addOnFailureListener() {
                Toast.makeText(
                    requireContext(),
                    "Error",
                    Toast.LENGTH_LONG
                ).show()
            }
        val action = SessionContentHostAddDirections.actionSessionContentHostAddToSessionContentHost(sessionID,sessionName, details, date, startTime, endTime)
        findNavController().navigate(action)

    }
    private val launcher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        pdfFileUri = uri
        val fileName = uri?.let { DocumentFile.fromSingleUri(requireContext(), it)?.name }
        PDFName.text = fileName.toString()
    }
}

