package com.example.assignment

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.Locale

class HomePageAdapter(private val context: Context, private var dataList: List<DataClass>) : RecyclerView.Adapter<MyViewHolder>() {


    //Edit
    interface OnEditClickListener {
        fun onEditClick(position: Int)
    }

    private var onEditClickListener: OnEditClickListener? = null

    fun setOnEditClickListener(listener: OnEditClickListener) {
        onEditClickListener = listener
    }


    //Delete
    interface OnDeleteClickListener {
        fun onDeleteClick(position: Int)
    }
    private var onDeleteClickListener: OnDeleteClickListener? = null

    fun setOnDeleteClickListener(listener: OnDeleteClickListener) {
        onDeleteClickListener = listener
    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.recycler_item, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = dataList[position]

        // Generate current date and time
        val currentDateAndTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(System.currentTimeMillis())

        Glide.with(context).load(currentItem.dataImage).into(holder.recImage)
        holder.recTitle.text = currentItem.dataTitle
        holder.recDesc.text = currentItem.dataDesc
        holder.recDate.text = currentItem.postTime
        holder.recUserName.text = currentItem.userName

        holder.recCard.setOnClickListener {
            val intent = Intent(context, HomepagePostActivity::class.java)
            intent.putExtra("Image", currentItem.dataImage)
            intent.putExtra("PostId", currentItem.postId)
            intent.putExtra("Description", currentItem.dataDesc)
            intent.putExtra("Title", currentItem.dataTitle)
            context.startActivity(intent)
        }


    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    fun searchDataList(searchList: List<DataClass>) {
        dataList = searchList
        notifyDataSetChanged()
    }

    fun updateDataList(newDataList: List<DataClass>) {
        dataList = newDataList
        notifyDataSetChanged()
    }
}


