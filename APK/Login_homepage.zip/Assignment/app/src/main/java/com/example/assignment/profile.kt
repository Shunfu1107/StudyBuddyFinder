package com.example.assignment

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.bumptech.glide.request.RequestOptions
import com.example.assignment.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class profile : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference
    private lateinit var dataList: ArrayList<DataClass>
    private lateinit var adapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().reference

        val gridLayoutManager = GridLayoutManager(this@profile, 1)
        binding.recyclerView.layoutManager = gridLayoutManager

        val builder = AlertDialog.Builder(this@profile)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        dataList = ArrayList()
        adapter = MyAdapter(this@profile, dataList)
        binding.recyclerView.adapter = adapter

        // Check if the user is authenticated
        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid
            val userRef = databaseReference.child("users").child(userId)

            // Retrieve user data from the database
            userRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Retrieve updated user information
                        val name = snapshot.child("name").getValue(String::class.java)
                        val email = currentUser.email
                        val profileImageUrl =
                            snapshot.child("photoUrl").getValue(String::class.java)

                        // Update UI with new data
                        binding.tvName.text = name
                        binding.tvEmail.text = email

                        Glide.with(this@profile)
                            .load(profileImageUrl)
                            .apply(RequestOptions.bitmapTransform(CircleCrop()))
                            .into(binding.profileImg)
                    }
                }


                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                    val errorMessage = "Database Error: ${error.message}"
                    // Display an error message to the user
                    Toast.makeText(this@profile, errorMessage, Toast.LENGTH_SHORT).show()
                }


            })

            userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Get the current user's email
                        val userEmail = currentUser.email

                        // Retrieve user posts from the database based on the author's email
                        val databaseReference =
                            FirebaseDatabase.getInstance().getReference("HomePage")
                        val query = databaseReference.orderByChild("authorEmail").equalTo(userEmail)

                        // Add a ValueEventListener to listen for changes in the database
                        query.addValueEventListener(object : ValueEventListener {
                            override fun onDataChange(snapshot: DataSnapshot) {
                                dataList.clear()
                                for (itemSnapshot in snapshot.children) {
                                    val dataClass = itemSnapshot.getValue(DataClass::class.java)
                                    dataClass?.let { dataList.add(it) }
                                }
                                adapter.notifyDataSetChanged()
                                dialog.dismiss()
                            }

                            override fun onCancelled(error: DatabaseError) {
                                dialog.dismiss()
                            }
                        })
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    dialog.dismiss()
                }
            })

            binding.btnEditProfile.setOnClickListener {
                // Create an Intent to navigate to edit_profile activity
                val intent = Intent(this, edit_profile::class.java)
                startActivity(intent)
            }

            binding.fab.setOnClickListener {

                val intent = Intent(this@profile, UploadActivity::class.java)
                startActivity(intent)

            }

            binding.btnSetting.setOnClickListener(){
                val intent = Intent(this, SettingActivity::class.java)
                startActivity(intent)
            }
        }
    }
}