package com.example.assignment.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.Data.SessionContent
import com.example.assignment.R

class SessionContentHostAdapter (private var sessionContentList: List<SessionContent>, private val listener: SessionContentHostAdapter.OnItemClickListener) : RecyclerView.Adapter
<SessionContentHostAdapter.MyViewHolder>(){
    class MyViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){
        val tvContentHostDate: TextView = itemView.findViewById(R.id.tvContentHostDate)
        val tvContentHost: TextView = itemView.findViewById(R.id.tvContentHost)
        val tvPDF:TextView = itemView.findViewById(R.id.tvPDF)
        val ivPDF:ImageView = itemView.findViewById(R.id.ivPDF)
        val ivBtnDeleteContent:ImageButton = itemView.findViewById(R.id.ivBtnDeleteContent)
        val ivBtnEditContent:ImageButton = itemView.findViewById(R.id.ivBtnEditContent)

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate( R.layout.session_content_host_cell, parent, false )
        return MyViewHolder(itemView)
    }
    override fun getItemCount(): Int {
        return sessionContentList.size
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = sessionContentList[position]
        holder.tvContentHostDate.text = currentItem.date
        holder.tvContentHost.text=currentItem.sessionContent

        if(currentItem.pdfPath!="null"){
            holder.tvPDF.visibility=View.VISIBLE
            holder.ivPDF.visibility=View.VISIBLE
        }else{
            holder.tvPDF.visibility=View.GONE
            holder.ivPDF.visibility=View.GONE

        }

        holder.ivBtnDeleteContent.setOnClickListener{
            listener.onItemClickDeleteContent(currentItem.sessionContentID.toString())
        }
        holder.ivBtnEditContent.setOnClickListener{
            listener.onItemClickEditContent(currentItem.sessionContentID.toString())
        }
    }
    interface OnItemClickListener {
        fun onItemClickDeleteContent(sessionContentID: String)
        fun onItemClickEditContent(sessionContentID: String)
//        fun onItemClickPDF()
    }

}