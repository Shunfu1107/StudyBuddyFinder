package com.example.assignment

data class GroupChat(
    val chatID: String = "",
    val groupName: String = "",
    val groupImageUrl: String = "",
    val members: List<String> = listOf(),
    val lastMessage: String = "",
    val lastMsgDateTime: String = "",
    val pinned: Boolean = false,
    val admin: String = "" // Add admin field
)
