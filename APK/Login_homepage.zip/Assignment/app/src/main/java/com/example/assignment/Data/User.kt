package com.example.assignment.Data

data class User(val emailAddress:String?=null, val profilePicURL:String?=null, val userID:String?=null ,val username:String?=null)
