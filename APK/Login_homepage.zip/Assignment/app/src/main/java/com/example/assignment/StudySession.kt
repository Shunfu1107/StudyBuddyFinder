package com.example.assignment

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.Adapter.AcceptSessionAdapter
import com.example.assignment.Adapter.HostSessionAdapter
import com.example.assignment.Adapter.PendingSessionAdapter
import com.example.assignment.Data.StudySessionData
import com.example.assignment.Data.UserStudySession
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class StudySession : Fragment(), AcceptSessionAdapter.OnItemClickListener,
    PendingSessionAdapter.OnItemClickListener, HostSessionAdapter.OnItemClickListener {
    private lateinit var recyclerViewSessionAccepted: RecyclerView
    private lateinit var recyclerViewSessionPending: RecyclerView
    private lateinit var recyclerViewSessionHost: RecyclerView
    private lateinit var pendingSessionList: ArrayList<StudySessionData>
    private lateinit var acceptSessionList: ArrayList<StudySessionData>
    private lateinit var hostSessionList: ArrayList<StudySessionData>
    private lateinit var dbRefSession: DatabaseReference
    private var userID: String = "1"

    private lateinit var dbRefUserStudySession: DatabaseReference
    private lateinit var userStudySessionList: ArrayList<UserStudySession>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_study_session, container, false);
        val btnJoinSession: ImageButton = view.findViewById(R.id.btnJoinSession)
        val btnCreateSession: ImageButton = view.findViewById(R.id.btnCreateSession)
        val tvBtnSessionAccepted: TextView = view.findViewById(R.id.tvBtnSessionAccepted)
        val tvBtnSessionPending: TextView = view.findViewById(R.id.tvBtnSessionPending)
        val tvBtnSessionHost: TextView = view.findViewById(R.id.tvBtnSessionHost)


        recyclerViewSessionPending = view.findViewById(R.id.recyclerViewSessionPending)
        recyclerViewSessionPending.layoutManager = LinearLayoutManager(context)

        recyclerViewSessionAccepted = view.findViewById(R.id.recyclerViewSessionAccepted)
        recyclerViewSessionAccepted.layoutManager = LinearLayoutManager(context)

        recyclerViewSessionHost = view.findViewById(R.id.recyclerViewSessionHost)
        recyclerViewSessionHost.layoutManager = LinearLayoutManager(context)

        tvBtnSessionAccepted.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))
        tvBtnSessionAccepted.setTypeface(null, Typeface.BOLD)
        recyclerViewSessionPending.visibility = View.GONE
        recyclerViewSessionHost.visibility = View.GONE

        dbRefSession = FirebaseDatabase.getInstance().getReference("StudySession")
        dbRefUserStudySession = FirebaseDatabase.getInstance().getReference("UserStudySession")
        pendingSessionList = arrayListOf()
        acceptSessionList = arrayListOf()
        userStudySessionList = arrayListOf()
        hostSessionList = arrayListOf()

        fetchUserStudySessionData()

        tvBtnSessionAccepted.setOnClickListener() {
            tvBtnSessionAccepted.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.black
                )
            )
            tvBtnSessionPending.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.lightgrey
                )
            )
            tvBtnSessionHost.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.lightgrey
                )
            )

            tvBtnSessionAccepted.setTypeface(null, Typeface.BOLD)
            tvBtnSessionPending.setTypeface(null, Typeface.NORMAL)
            tvBtnSessionHost.setTypeface(null, Typeface.NORMAL)

            recyclerViewSessionAccepted.visibility = View.VISIBLE
            recyclerViewSessionPending.visibility = View.GONE
            recyclerViewSessionHost.visibility = View.GONE

        }
        tvBtnSessionPending.setOnClickListener() {
            tvBtnSessionAccepted.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.lightgrey
                )
            )
            tvBtnSessionPending.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.black
                )
            )
            tvBtnSessionHost.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.lightgrey
                )
            )


            tvBtnSessionPending.setTypeface(null, Typeface.BOLD)
            tvBtnSessionAccepted.setTypeface(null, Typeface.NORMAL)
            tvBtnSessionHost.setTypeface(null, Typeface.NORMAL)

            recyclerViewSessionPending.visibility = View.VISIBLE
            recyclerViewSessionAccepted.visibility = View.GONE
            recyclerViewSessionHost.visibility = View.GONE
        }
        tvBtnSessionHost.setOnClickListener() {
            tvBtnSessionAccepted.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.lightgrey
                )
            )
            tvBtnSessionPending.setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.lightgrey
                )
            )
            tvBtnSessionHost.setTextColor(ContextCompat.getColor(requireContext(), R.color.black))

            tvBtnSessionAccepted.setTypeface(null, Typeface.NORMAL)
            tvBtnSessionPending.setTypeface(null, Typeface.NORMAL)
            tvBtnSessionHost.setTypeface(null, Typeface.BOLD)



            recyclerViewSessionAccepted.visibility = View.GONE
            recyclerViewSessionPending.visibility = View.GONE
            recyclerViewSessionHost.visibility = View.VISIBLE

        }



        btnJoinSession.setOnClickListener {
            val action = StudySessionDirections.actionStudySessionToSessionSearch()
            findNavController().navigate(action)
        }
        btnCreateSession.setOnClickListener {
            val action = StudySessionDirections.actionStudySessionToCreateStudySession()
            findNavController().navigate(action)
        }


//       val id = UUID.randomUUID()
//       val userStudySession = UserStudySession(id.toString(),"User1","c911795d-99e3-4fc4-8068-25c10efcb55a","pending")
//        dbRefUserStudySession.child(userStudySession.userStudySessionID!!).setValue(userStudySession)
//            .addOnCompleteListener {
//                Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
//            }
//            .addOnFailureListener {
//                Toast.makeText(
//                    requireContext(),
//                    "Error ${it.toString()}",
//                    Toast.LENGTH_LONG
//                ).show()
//            }
        return view
    }

    private fun fetchUserStudySessionData() {
        dbRefUserStudySession.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                userStudySessionList.clear()

                if (snapshot.exists()) {
                    for (studySessionSnap in snapshot.children) {
                        val studySession = studySessionSnap.getValue(UserStudySession::class.java)
                        if (studySession != null) {

                            userStudySessionList.add(studySession!!)

                        }

                    }
                    fetchData()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun fetchData() {

        dbRefSession.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                acceptSessionList.clear()
                pendingSessionList.clear()
                hostSessionList.clear()
                if (snapshot.exists()) {
                    for (studySessionSnap in snapshot.children) {
                        val studySession = studySessionSnap.getValue(StudySessionData::class.java)
                        if (studySession != null) {
                            for (userStudySession in userStudySessionList) {
                                if (userStudySession.userID == userID) {
                                    if (userStudySession.sessionID == studySession.sessionID) {
                                        if (userStudySession.status == "pending") {
                                            pendingSessionList.add(studySession)
                                        } else if (userStudySession.status == "accept") {
                                            acceptSessionList.add(studySession)
                                        } else if (userStudySession.status == "host") {
                                            hostSessionList.add(studySession)
                                        }
                                    }
                                }
                            }
                        }

                    }
                    recyclerViewSessionAccepted.adapter =
                        AcceptSessionAdapter(acceptSessionList, this@StudySession)
                    recyclerViewSessionPending.adapter =
                        PendingSessionAdapter(pendingSessionList, this@StudySession)
                    recyclerViewSessionHost.adapter =
                        HostSessionAdapter(hostSessionList, this@StudySession)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    override fun onItemClickQuit(sessionID: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to Quit?")
            .setCancelable(false)
            .setPositiveButton("Quit") { dialog, id ->
                // Delete selected note from database
                for (item in userStudySessionList) {
                    if (sessionID == item.sessionID && userID == item.userID) {
                        dbRefUserStudySession.child(item.userStudySessionID!!).removeValue()
                            .addOnCompleteListener {
                                Toast.makeText(requireContext(), "Quit", Toast.LENGTH_LONG).show()
                            }
                    }
                }
            }
            .setNegativeButton("Cancel") { dialog, id ->
                // Dismiss the dialog
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }



    override fun onItemClickDecline(sessionID: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to Decline?")
            .setCancelable(false)
            .setPositiveButton("Decline") { dialog, id ->
                // Delete selected note from database
                for (item in userStudySessionList) {
                    if (sessionID == item.sessionID && userID == item.userID) {
                        dbRefUserStudySession.child(item.userStudySessionID!!).removeValue()
                            .addOnCompleteListener {
                                Toast.makeText(requireContext(), "Declined", Toast.LENGTH_LONG)
                                    .show()
                            }
                    }
                }
            }
            .setNegativeButton("No") { dialog, id ->
                // Dismiss the dialog
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    override fun onItemClickAccept(sessionID: String) {
        for (item in userStudySessionList) {
            if (sessionID == item.sessionID && userID == item.userID) {
                dbRefUserStudySession.child(item.userStudySessionID!!).child("status")
                    .setValue("accept").addOnCompleteListener {
                    Toast.makeText(requireContext(), "Accepted", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onItemClickDelete(sessionID: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to Delete?")
            .setCancelable(false)
            .setPositiveButton("Delete") { dialog, id ->
                // Delete selected note from database
                for (item in userStudySessionList) {
                    if (sessionID == item.sessionID) {
                        dbRefUserStudySession.child(item.userStudySessionID!!).removeValue()
                            .addOnCompleteListener {
                                Toast.makeText(requireContext(), "Deleted", Toast.LENGTH_LONG)
                                    .show()
                            }
                    }
                }
                dbRefSession.child(sessionID).removeValue()
            }
            .setNegativeButton("Cancel") { dialog, id ->
                // Dismiss the dialog
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    override fun onItemClickHostContent(
        sessionID: String,
        sessionName: String,
        details: String,
        date: String,
        startTime: String,
        endTime: String
    ) {
        val action = StudySessionDirections.actionStudySessionToSessionContentHost(sessionID,sessionName, details, date, startTime, endTime)
        findNavController().navigate(action)    }

    override fun onItemClickContent(
        sessionID: String,
        sessionName: String,
        details: String,
        date: String,
        startTime: String,
        endTime: String
    ) {
        val action = StudySessionDirections.actionStudySessionToSessionContentHost(sessionID,sessionName, details, date, startTime, endTime)
        findNavController().navigate(action)
    }

}
