package com.example.assignment

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.GenericTypeIndicator
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage

class GroupDetails : Fragment(), MessageAdapter.MessageItemLongClickListener,
    ImageAdapter.ImageAdapterListener {
    private lateinit var receiverId: String
    private lateinit var username: String
    private lateinit var message: String
    private lateinit var datetime: String
    private lateinit var imageUrl: String
    private lateinit var chatId: String
    private val CAMERA_PERMISSION_CODE = 1000
    private val IMAGE_CAPTURE_CODE = 1001
    private var imageUri: Uri? = null
    private val imageUriList: MutableList<Uri> = mutableListOf()
    private lateinit var messageList: MutableList<Message>
    private lateinit var firestore: FirebaseFirestore
    private lateinit var dbRef: DatabaseReference
    private lateinit var recyclerView: RecyclerView
    private lateinit var messageAdapter: MessageAdapter
    private lateinit var popupWindow: PopupWindow

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        // Initialize Firebase Firestore
        firestore = FirebaseFirestore.getInstance()

        // Initialize Firebase Storage
        val storage = Firebase.storage

        val view = inflater.inflate(R.layout.fragment_group_details, container, false)

        // Initialize your views
        val editTextMessage = view.findViewById<TextInputEditText>(R.id.editTextMessage)

        // Add a TextWatcher to the TextInputEditText
        editTextMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Check if the current text is being deleted
                if (s != null && s.isNotEmpty() && start == 0 && count == s.length && after == 0) {
                    // Show the hint text
                    editTextMessage.hint = "Message"
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // No implementation needed
            }

            override fun afterTextChanged(s: Editable?) {
                // Check if the text is empty
                if (s.isNullOrEmpty()) {
                    // Show the hint text
                    editTextMessage.hint = "Message"
                } else {
                    // Hide the hint text
                    editTextMessage.hint = ""
                }
            }
        })

        val backButton = view.findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {

            // Navigate to the ChatDetailsFragment using the action
            val action = GroupDetailsDirections.actionGroupDetailsToChatMenu()
            findNavController().navigate(action)
        }

        // Initialize your views
        val trippleDot = view.findViewById<ImageView>(R.id.trippleDot)
        trippleDot.setOnClickListener {
            showOverflowMenu(it)
        }

        chatId = arguments?.getString("chatId") ?: ""
        username = arguments?.getString("groupName") ?: ""
        imageUrl = arguments?.getString("imgUrl") ?: ""

        // Set the username as the toolbar title
        val toolbarTitle = view.findViewById<TextView>(R.id.toolbar_title)
        toolbarTitle.text = username

        val imageView = view.findViewById<ImageView>(R.id.abc)
        Glide.with(requireContext())
            .load(imageUrl)
            .transform(CircleCrop())
            .placeholder(R.drawable.grouppfp) // Placeholder image while loading
            .error(R.drawable.grouppfp) // Error image if loading fails
            .into(imageView)

        return view
    }

    override fun onItemLongClick(message: Message) {
        var loggedinUser: String = "KC99FVvo2hRlC7MbJX2P9E3lRh13"

        val options: List<String>
        if (message.senderId == loggedinUser) {
            options = mutableListOf<String>("Copy Text", "Delete Message")
        } else {
            options = mutableListOf<String>("Copy Text")
        }

        val builder = androidx.appcompat.app.AlertDialog.Builder(requireContext())
        builder.setItems(options.toTypedArray()) { _, which ->
            when (which) {
                0 -> {
                    // Copy text option selected
                    copyToClipboard(message.chatMessage)
                }

                1 -> {
                    // Delete option selected
                    showDeleteMessageConfirmation(message)
                }
            }
        }
        builder.show()
    }

    private fun showDeleteMessageConfirmation(message: Message) {
        val builder = androidx.appcompat.app.AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to delete this message?")
        builder.setPositiveButton("Delete") { _, _ ->
            deleteMessage(message)
        }
        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun copyToClipboard(text: String) {
        val clipboard =
            requireActivity().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("copiedText", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(requireContext(), "Text copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    private fun deleteMessage(message: Message) {
        // Get a reference to the "messages" node in Realtime Database
        val dbRef = FirebaseDatabase.getInstance().getReference("Messages").child(chatId)

        // Query to find the message to delete
        val query = dbRef.orderByChild("timestamp").equalTo(message.timestamp)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // Loop through each message
                for (snapshot in dataSnapshot.children) {
                    // Check if the current message matches the message to be deleted
                    if (snapshot.exists() && snapshot.getValue(Message::class.java) == message) {
                        // Remove the message from the database
                        snapshot.ref.removeValue()
                            .addOnSuccessListener {
                                Log.d(ContentValues.TAG, "Message deleted successfully")

                                // Remove the deleted message from the messageList
                                val position = messageList.indexOf(message)
                                if (position != -1) {
                                    messageList.removeAt(position)
                                    messageAdapter.notifyItemRemoved(position)
                                }

                                // Update the last message and datetime
                                updateLastMessageAndDatetime(chatId)

                            }
                            .addOnFailureListener { e ->
                                Log.e(ContentValues.TAG, "Error deleting message", e)
                                // Handle the error appropriately
                            }
                        break // Exit the loop after deleting the message
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(ContentValues.TAG, "Error deleting message:", databaseError.toException())
                // Handle the error appropriately
            }
        })
    }

    private fun updateLastMessageAndDatetime(chatId: String) {
        val database = FirebaseDatabase.getInstance()
        val chatRef = database.getReference("Chats").child(chatId)

        // Get the last message in the chat
        val lastMessageQuery =
            database.getReference("Messages").child(chatId).orderByChild("timestamp").limitToLast(1)
        lastMessageQuery.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (postSnapshot in dataSnapshot.children) {
                    val lastMessage = postSnapshot.child("chatMessage").getValue(String::class.java)
                    val lastMessageDateTime =
                        postSnapshot.child("timestamp").getValue(String::class.java)
                    val imageUrls = postSnapshot.child("chatImages")
                        .getValue(object : GenericTypeIndicator<List<String>>() {})

                    // Update the last message and datetime
                    val lastMessageMap = HashMap<String, Any>()
                    if (lastMessage != "" && !imageUrls.isNullOrEmpty()) {
                        // If there's a message and no image, set it as the last message
                        lastMessageMap["lastMessage"] = "\uD83D\uDCF7 $lastMessage"
                    } else if (lastMessage != "") {
                        // If there's only a message, set it as the last message
                        lastMessageMap["lastMessage"] = "$lastMessage"
                    } else if (!imageUrls.isNullOrEmpty()) {
                        // If there's no message but image, set the last message as image
                        lastMessageMap["lastMessage"] = "\uD83D\uDCF7 Image"
                    } else {
                        lastMessageMap["lastMessage"] = ""
                    }

                    lastMessageMap["lastMsgDateTime"] = lastMessageDateTime ?: ""

//                    lastMessageMap["lastMsgDateTime"] = datetime

                    chatRef.updateChildren(lastMessageMap)
                        .addOnSuccessListener {
                            Log.d(
                                ContentValues.TAG,
                                "Last message and datetime updated successfully in the database."
                            )
                        }
                        .addOnFailureListener { e ->
                            Log.e(
                                ContentValues.TAG,
                                "Error updating last message and datetime in the database: ${e.message}"
                            )
                        }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(ContentValues.TAG, "updateLastMessageAndDatetime:onCancelled", databaseError.toException())
            }
        })
    }

    override fun onRemoveImageClick(position: Int) {
        TODO("Not yet implemented")
    }

    override fun updateRecyclerViewVisibility() {
        val recyclerView: RecyclerView = requireView().findViewById(R.id.recyclerView)
        recyclerView.visibility = if (imageUriList.isNotEmpty()) View.VISIBLE else View.GONE
    }

        private fun showOverflowMenu(anchor: View) {
        val view = layoutInflater.inflate(R.layout.bottom_sheet_menu, null)

//        val clearChat = view.findViewById<TextView>(R.id.clearChat)
//
//        clearChat.setOnClickListener {
//            // Create a confirmation dialog builder
//            val builder = AlertDialog.Builder(requireContext())
//
//            // Set dialog title and message
//            builder.setTitle("Clear Chat")
//            builder.setMessage("Are you sure you want to delete all messages in this chat? This action cannot be undone.")
//
//            // Set positive and negative buttons
//            builder.setPositiveButton("Clear") { dialog, which ->
//                // Call the message deletion function (defined below)
//                deleteAllMessages(chatId)
//                dismissPopupWindow() // Dismiss the popup window
//                dialog.dismiss() // Dismiss the confirmation dialog
//            }
//
//            builder.setNegativeButton("Cancel") { dialog, which ->
//                dialog.dismiss() // Dismiss the confirmation dialog
//            }
//
//            // Create and show the dialog
//            builder.create().show()
//        }

        popupWindow = PopupWindow(
            view,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )

        // Show the menu below the anchor view
        popupWindow.showAsDropDown(anchor)
    }

    private fun dismissPopupWindow() {
        if (popupWindow.isShowing) {
            popupWindow.dismiss()
        }
    }


}