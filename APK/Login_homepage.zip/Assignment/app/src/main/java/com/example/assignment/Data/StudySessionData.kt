package com.example.assignment.Data

data class StudySessionData(val sessionID:String?=null, val sessionName:String?=null, val details : String?=null, val date : String?=null, val startTime : String?=null, val endTime:String?=null)

