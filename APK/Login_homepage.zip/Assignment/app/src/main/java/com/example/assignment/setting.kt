package com.example.assignment

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.assignment.databinding.ActivitySettingBinding
import com.google.firebase.auth.FirebaseAuth

class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up click listener for the logout button
        binding.btnLogout.setOnClickListener {
            // Log out the user
            FirebaseAuth.getInstance().signOut()

            // Redirect to the login page
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)

            // Finish the current activity to prevent going back to it when pressing back
            finish()
        }
    }
}