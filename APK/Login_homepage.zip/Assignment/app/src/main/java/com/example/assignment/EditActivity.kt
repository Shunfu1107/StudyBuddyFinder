package com.example.assignment

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class EditActivity : AppCompatActivity() {
    private lateinit var editTitle: EditText
    private lateinit var editDescription: EditText
    private lateinit var editImage: ImageView
    private lateinit var saveEditButton: Button

    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        // Initialize views
        editTitle = findViewById(R.id.editTitle)
        editDescription = findViewById(R.id.editDesc)
        editImage = findViewById(R.id.editImage)
        saveEditButton = findViewById(R.id.saveEditButton)

        // Retrieve post data from Intent extras
        val postId = intent.getStringExtra("PostId")
        val title = intent.getStringExtra("Title")
        val description = intent.getStringExtra("Description")
        val imageUrl = intent.getStringExtra("Image")

        // Populate EditText and ImageView with current post details
        editTitle.setText(title)
        editDescription.setText(description)
        Glide.with(this).load(imageUrl).into(editImage)

        // Handle image click to select a new image
        editImage.setOnClickListener {
            selectImage.launch("image/*")
        }

        // Handle saveEditButton click
        saveEditButton.setOnClickListener {
            // Get edited post details from EditText fields
            val newTitle = editTitle.text.toString()
            val newDescription = editDescription.text.toString()

            // Check if title and description are not empty
            if (newTitle.isEmpty() || newDescription.isEmpty()) {
                // Notify the user that title and description cannot be empty
                Toast.makeText(this, "Title and description cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Update the post in Firebase Realtime Database
            val databaseReference = FirebaseDatabase.getInstance().getReference("HomePage").child(postId!!)
            databaseReference.child("dataTitle").setValue(newTitle)
            databaseReference.child("dataDesc").setValue(newDescription)

            // Update the postTime
            val malaysiaDateTime = getMalaysiaDateTime()
            databaseReference.child("postTime").setValue(malaysiaDateTime)

            selectedImageUri?.let { uri ->
                uploadImage(postId!!, uri)
            } ?: run {
                // If no new image was selected, finish the activity
                Toast.makeText(this, "Image updated successfully", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, profile::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                finish()
            }
        }

    }

    private fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur") // Malaysia time zone
        val malaysiaLocale = Locale("ms", "MY") // Malaysia locale
        val dateFormat =
            SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale) // Adjust format as needed
        dateFormat.timeZone = malaysiaTimeZone

        return dateFormat.format(Date())
    }

    private val selectImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                // Display the selected image in the ImageView
                Glide.with(this).load(it).into(editImage)
                selectedImageUri = it
            }
        }

    private fun uploadImage(postId: String, uri: Uri) {
        // Upload the image to Firebase Storage and get the download URL
        val storageRef = FirebaseStorage.getInstance().getReference("images/$postId.jpg")
        storageRef.putFile(uri)
            .addOnSuccessListener { taskSnapshot ->
                // Image uploaded successfully, get the download URL
                storageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    // Update the image URL in the Firebase Realtime Database
                    val databaseReference = FirebaseDatabase.getInstance().getReference("HomePage").child(postId)
                    databaseReference.child("dataImage").setValue(downloadUri.toString())

                    // Provide feedback to the user
                    Toast.makeText(this, "Post updated successfully", Toast.LENGTH_SHORT).show()


                    // Finish the activity to return to MainActivity
                    finish()
                }
            }
            .addOnFailureListener { exception ->
                // Handle failures, such as permission errors or network issues
                Toast.makeText(this, "Failed to upload image: ${exception.message}", Toast.LENGTH_SHORT).show()
            }
    }
}