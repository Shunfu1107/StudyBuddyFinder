package com.example.assignment

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import com.bumptech.glide.Glide
import androidx.appcompat.app.AppCompatActivity
import com.example.assignment.databinding.ActivityProfileSetupBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.util.Calendar

class profile_setup : AppCompatActivity() {

    private lateinit var binding: ActivityProfileSetupBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var firebaseStorage: FirebaseStorage
    private lateinit var selectedPhotoUri: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        firebaseDatabase = FirebaseDatabase.getInstance()
        firebaseStorage = FirebaseStorage.getInstance()

        val btnCalander: ImageButton = findViewById(R.id.btnCalander)

        btnCalander.setOnClickListener {
            showDatePickerDialog()
        }

        binding.btnNext.setOnClickListener {
            val name = binding.etName.text.toString()
            val gender = if (binding.rdBtnMale.isChecked) "Male" else "Female"
            val birthDate = binding.etBirthDate.text.toString()
            val courseOfStudy = binding.etCourseStudy.text.toString()

            // Check if any field is empty
            if (name.isNotEmpty() && birthDate.isNotEmpty() && courseOfStudy.isNotEmpty()) {
                // Upload photo to Firebase Storage
                uploadPhoto(name, gender, birthDate, courseOfStudy)
            } else {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnUpload.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }
    }

    private fun uploadPhoto(name: String, gender: String, birthDate: String, courseOfStudy: String) {
        // Check if photo URI is selected
        if (::selectedPhotoUri.isInitialized) {
            val photoRef = firebaseStorage.reference.child("profile_photos").child("${firebaseAuth.currentUser?.uid}.jpg")
            photoRef.putFile(selectedPhotoUri)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Photo uploaded successfully, get download URL
                        photoRef.downloadUrl.addOnSuccessListener { uri ->
                            // Save user profile data including photo URL to Firebase Database
                            saveProfileData(name, gender, birthDate, courseOfStudy, uri.toString())
                        }
                    } else {
                        Toast.makeText(this, "Failed to upload photo.", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            // No photo selected
            saveProfileData(name, gender, birthDate, courseOfStudy, "")
        }
    }

    private fun saveProfileData(name: String, gender: String, birthDate: String, courseOfStudy: String, photoUrl: String) {
        val userId = firebaseAuth.currentUser?.uid
        if (userId != null) {
            val userRef = firebaseDatabase.reference.child("users").child(userId)

            // Instead of directly setting the UserProfile object,
            // let's create a HashMap to represent the data structure you want
            val profileData = HashMap<String, Any>()
            profileData["name"] = name
            profileData["gender"] = gender
            profileData["birthDate"] = birthDate
            profileData["courseOfStudy"] = courseOfStudy
            profileData["photoUrl"] = photoUrl

            // Update the user reference with the profile data
            userRef.updateChildren(profileData)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Profile saved successfully.", Toast.LENGTH_SHORT).show()
                        // Proceed to the profile activity
                        navigateToProfile()
                    } else {
                        Toast.makeText(this, "Failed to save profile.", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun navigateToProfile() {
        val intent = Intent(this, profile::class.java)
        startActivity(intent)
        finish() // Optional: to prevent user from going back to profile setup screen
    }

    companion object {
        private const val PICK_IMAGE_REQUEST = 123
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            // Get the selected photo URI from the intent data
            val imageUri: Uri? = data.data
            imageUri?.let { uri ->
                selectedPhotoUri = uri
                // Load the selected photo into the ImageButton using Glide
                Glide.with(this)
                    .load(uri)
                    .into(binding.btnUpload)
            }
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                // Handle the selected date here
                val selectedDate = "$selectedDayOfMonth/${selectedMonth + 1}/$selectedYear"
                // For example, update a TextView with the selected date
                binding.etBirthDate.setText(selectedDate)
            },
            year,
            month,
            dayOfMonth
        )

        datePickerDialog.show()
    }
}


