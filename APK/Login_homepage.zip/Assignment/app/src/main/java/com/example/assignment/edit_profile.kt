package com.example.assignment

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.bumptech.glide.request.RequestOptions
import com.example.assignment.databinding.ActivityEditProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.database.*
import java.util.Calendar

class edit_profile : AppCompatActivity() {

    private lateinit var binding: ActivityEditProfileBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().reference

        val currentUser = firebaseAuth.currentUser
        if (currentUser != null) {
            // Populate email and name
            binding.etEmail.setText(currentUser.email)
            binding.etName.setText(currentUser.displayName)

            // Retrieve additional user information from Firebase Database
            val userId = currentUser.uid
            val userRef = databaseReference.child("users").child(userId)
            userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Retrieve and populate additional user information
                        val name = snapshot.child("name").getValue(String::class.java)
                        val gender = snapshot.child("gender").getValue(String::class.java)
                        val dob = snapshot.child("birthDate").getValue(String::class.java)
                        val profileImageUrl = snapshot.child("photoUrl").getValue(String::class.java)

                        // Populate other fields like gender, DOB, etc.
                        binding.etName.setText(name)
                        binding.etGender.setText(gender)
                        binding.etBirthDate.setText(dob)

                        Glide.with(this@edit_profile)
                            .load(profileImageUrl)
                            .apply(RequestOptions.bitmapTransform(CircleCrop()))
                            .into(binding.profileImg)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                }
            })

            val btnCalander: ImageButton = findViewById(R.id.btnCalander)

            btnCalander.setOnClickListener {
                showDatePickerDialog()
            }

            binding.btnSave.setOnClickListener {
                // Get updated user information
                val newName = binding.etName.text.toString().trim()
                val newBirthDate = binding.etBirthDate.text.toString().trim()

                // Update user information in Firebase Authentication
                currentUser.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(newName).build())
                    .addOnCompleteListener { profileTask ->
                        if (profileTask.isSuccessful) {
                            // Update user information in Firebase Database
                            val updatedUserData = HashMap<String, Any>()
                            updatedUserData["name"] = newName
                            updatedUserData["birthDate"] = newBirthDate
                            // Update other fields as needed

                            userRef.updateChildren(updatedUserData)
                                .addOnCompleteListener { updateTask ->
                                    if (updateTask.isSuccessful) {
                                        Toast.makeText(this, "Profile updated successfully.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(this, "Failed to update profile.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        } else {
                            Toast.makeText(this, "Failed to update profile.", Toast.LENGTH_SHORT).show()
                        }
                    }
            }

        }
    }
    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                // Handle the selected date here
                val selectedDate = "$selectedDayOfMonth/${selectedMonth + 1}/$selectedYear"
                // For example, update a TextView with the selected date
                binding.etBirthDate.setText(selectedDate)
            },
            year,
            month,
            dayOfMonth
        )

        datePickerDialog.show()
    }
}
