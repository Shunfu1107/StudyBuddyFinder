package com.example.assignment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.Adapter.AcceptSessionAdapter
import com.example.assignment.Adapter.NormalSessionAdapter
import com.example.assignment.Adapter.PendingSessionAdapter
import com.example.assignment.Data.StudySessionData
import com.example.assignment.Data.UserStudySession
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Locale
import java.util.UUID


class SessionSearch : Fragment() , NormalSessionAdapter.OnItemClickListener{

    private lateinit var recyclerView: RecyclerView
    private var sessionList: ArrayList<StudySessionData> = ArrayList()
    private lateinit var dbRefSession : DatabaseReference
    private lateinit var searchViewSession: SearchView
    private var adapter: NormalSessionAdapter = NormalSessionAdapter(ArrayList(),this@SessionSearch)
    private var userID: String = "1"
    private lateinit var dbRefUserStudySession: DatabaseReference
    private lateinit var userStudySessionList: ArrayList<UserStudySession>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view =  inflater.inflate(R.layout.fragment_session_search, container, false)

        searchViewSession  = view.findViewById(R.id.searchViewSession)
        searchViewSession.clearFocus()

        recyclerView = view.findViewById(R.id.recyclerViewSessionSearch)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(context)
        dbRefSession = FirebaseDatabase.getInstance().getReference("StudySession")
        dbRefUserStudySession = FirebaseDatabase.getInstance().getReference("UserStudySession")
        userStudySessionList = arrayListOf()
        sessionList = arrayListOf()

        fetchUserStudySessionData()


        searchViewSession.setOnQueryTextListener(object :SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchViewSession.clearFocus()
                return false

            }
            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }

        })

        return view

    }
    private fun filterList(query: String?) {

        if (query != null) {
            val filteredList = ArrayList<StudySessionData>()
            for (i in sessionList) {
                if (i.sessionName!!.lowercase(Locale.ROOT).contains(query)) {
                    filteredList.add(i)
                }
            }

            if (filteredList.isEmpty()) {
                Toast.makeText(requireContext(), "No Data found", Toast.LENGTH_SHORT).show()
            } else {
               adapter.setFilteredList(filteredList)
            }
        }
    }

    private fun fetchUserStudySessionData() {
        dbRefUserStudySession.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                sessionList.clear()
                userStudySessionList.clear()
                if (snapshot.exists()) {
                    for (studySessionSnap in snapshot.children) {
                        val studySession = studySessionSnap.getValue(UserStudySession::class.java)
                        if (studySession != null && studySession.userID == userID) {

                            userStudySessionList.add(studySession!!)

                        }

                    }
                    fetchData()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun fetchData() {

        dbRefSession.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (studySessionSnap in snapshot.children) {
                        val studySession = studySessionSnap.getValue(StudySessionData::class.java)
                        var checkNormal = true
                        if (studySession != null) {

                            for (userStudySession in userStudySessionList) {
                                if (userStudySession.sessionID == studySession.sessionID) {
                                    checkNormal = false



                                }
                            }
                            if(checkNormal==true){
                                sessionList.add(studySession)
                            }
                        }

                    }
                   recyclerView.adapter = NormalSessionAdapter(sessionList,this@SessionSearch)

                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    override fun onItemClick(sessionId: String) {
        Toast.makeText(requireContext(), "Clicked session ID: $sessionId", Toast.LENGTH_SHORT).show()
        val id = UUID.randomUUID()
        val userStudySession = UserStudySession(id.toString(),userID,sessionId,"accept")
        dbRefUserStudySession.child(userStudySession.userStudySessionID!!).setValue(userStudySession)
            .addOnCompleteListener {
                Toast.makeText(requireContext(), "Data saved", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener {
                Toast.makeText(
                    requireContext(),
                    "Error ${it.toString()}",
                    Toast.LENGTH_LONG
                ).show()
            }

    }


}