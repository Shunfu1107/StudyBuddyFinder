package com.example.assignment

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.GenericTypeIndicator
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class ChatDetails : Fragment(), MessageAdapter.MessageItemLongClickListener,
    ImageAdapter.ImageAdapterListener {
    private lateinit var receiverId: String
    private lateinit var username: String
    private lateinit var message: String
    private lateinit var datetime: String
    private lateinit var imageUrl: String
    private lateinit var chatId: String
    private val CAMERA_PERMISSION_CODE = 1000
    private val IMAGE_CAPTURE_CODE = 1001
    private var imageUri: Uri? = null
    private val imageUriList: MutableList<Uri> = mutableListOf()
    private lateinit var messageList: MutableList<Message>
    private lateinit var firestore: FirebaseFirestore
    private lateinit var dbRef: DatabaseReference
    private lateinit var recyclerView: RecyclerView
    private lateinit var messageAdapter: MessageAdapter
    private lateinit var popupWindow: PopupWindow

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Initialize Firebase Firestore
        firestore = FirebaseFirestore.getInstance()

        // Initialize Firebase Storage
        val storage = Firebase.storage

        val view = inflater.inflate(R.layout.fragment_chatdetails, container, false)

        // Initialize your views
        val editTextMessage = view.findViewById<TextInputEditText>(R.id.editTextMessage)

        // Add a TextWatcher to the TextInputEditText
        editTextMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Check if the current text is being deleted
                if (s != null && s.isNotEmpty() && start == 0 && count == s.length && after == 0) {
                    // Show the hint text
                    editTextMessage.hint = "Message"
                }
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // No implementation needed
            }

            override fun afterTextChanged(s: Editable?) {
                // Check if the text is empty
                if (s.isNullOrEmpty()) {
                    // Show the hint text
                    editTextMessage.hint = "Message"
                } else {
                    // Hide the hint text
                    editTextMessage.hint = ""
                }
            }
        })

        val backButton = view.findViewById<ImageButton>(R.id.backButton)
        backButton.setOnClickListener {
            // Navigate to the ChatDetailsFragment using the action
            val action = ChatDetailsDirections.actionChatDetails2ToChatMenu()
            findNavController().navigate(action)
        }

        receiverId = arguments?.getString("userId") ?: ""

        // Initialize your views
        val trippleDot = view.findViewById<ImageView>(R.id.trippleDot)
        trippleDot.visibility = if (receiverId.isEmpty()) View.VISIBLE else View.GONE

        trippleDot.setOnClickListener {
            showOverflowMenu(it)
        }

        // Get the username from arguments
        username = arguments?.getString("username") ?: ""
        imageUrl = arguments?.getString("imgUrl") ?: ""
        chatId = arguments?.getString("chatId") ?: ""

        // Set the username as the toolbar title
        val toolbarTitle = view.findViewById<TextView>(R.id.toolbar_title)
        toolbarTitle.text = username

        Log.d(TAG, "ReceiverId: $receiverId")
        Log.d(TAG, "Image URL: $imageUrl")

        val imageView = view.findViewById<ImageView>(R.id.abc)
        Glide.with(requireContext())
            .load(imageUrl)
            .transform(CircleCrop())
            .placeholder(R.drawable.defprofile) // Placeholder image while loading
            .error(R.drawable.defprofile) // Error image if loading fails
            .into(imageView)

        view.findViewById<ImageButton>(R.id.buttonSendMessage).setOnClickListener {
            val messageContent = editTextMessage.text.toString().trim()
            if (messageContent.isNotEmpty() || imageUriList.isNotEmpty()) {
                // Handle sending the message (text, images, or both)
                sendMessage(chatId, messageContent, imageUriList)

                // Clear the message input field after sending
                editTextMessage.text = null
                imageUriList.clear()
                imageAdapter.notifyDataSetChanged()
            } else {
                // Display an error message or perform any other action as needed
                showAlert("Please enter a message or attach an image.")
            }
        }

        recyclerView = view.findViewById(R.id.msgRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        messageList = mutableListOf()
        messageAdapter = MessageAdapter(messageList, this)
        recyclerView.adapter = messageAdapter

        // Load messages
        loadMessages(chatId)

        return view
    }

    private fun showOverflowMenu(anchor: View) {
        val view = layoutInflater.inflate(R.layout.bottom_sheet_menu, null)

        val manageMember = view.findViewById<TextView>(R.id.managegroup)
        val leaveChatTxt = view.findViewById<TextView>(R.id.leaveChat)

        popupWindow = PopupWindow(
            view,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            true
        )

        // Show the menu below the anchor view
        popupWindow.showAsDropDown(anchor)

        // Add a click listener to the leave chat option
        leaveChatTxt.setOnClickListener {
            // Call the leave chat function here
            showLeaveChatConfirmationDialog()
            // Dismiss the popup window after leaving the chat
            popupWindow.dismiss()
        }
    }

    private fun showLeaveChatConfirmationDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Leave Chat")
        builder.setMessage("Are you sure you want to leave this chat?")
        builder.setPositiveButton("Leave") { dialog, which ->
            // Call the leave chat function if the user confirms
            leaveChat()
        }
        builder.setNegativeButton("Cancel") { dialog, which ->
            dialog.dismiss()
        }
        builder.show()
    }

    private fun leaveChat() {
        // Get sender id (the one that logs in)
        var userId: String = ""

        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser

        if (currentUser != null) {
            // User is signed in
            userId = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $userId")
        }

//        val userId = "KC99FVvo2hRlC7MbJX2P9E3lRh13" // Assuming this is the current user ID
        val chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatId)
        val membersRef = chatRef.child("members")

        chatRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val members = dataSnapshot.child("members").children.map { it.getValue(String::class.java) }.toMutableList()
                val chatAdminId = dataSnapshot.child("admin").getValue(String::class.java)
                if (members.contains(userId)) {
                    members.remove(userId) // Remove the user from the local list
                    if (userId == chatAdminId) {
                        // If the leaving user was the admin, assign a new admin
                        if (members.isNotEmpty()) {
                            // Assigning the first member as the admin
                            val newAdminId = members[0]
                            chatRef.child("admin").setValue(newAdminId).addOnCompleteListener { adminTask ->
                                if (adminTask.isSuccessful) {
                                    membersRef.setValue(members).addOnCompleteListener { memberTask ->
                                        if (memberTask.isSuccessful) {
                                            // User removed successfully
                                            Toast.makeText(context, "Left the chat", Toast.LENGTH_SHORT).show()
                                            val action = ChatDetailsDirections.actionChatDetails2ToChatMenu()
                                            findNavController().navigate(action)
                                        } else {
                                            // User removal failed
                                            Toast.makeText(context, "Failed to leave the chat", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    // Admin update failed
                                    Toast.makeText(context, "Failed to update admin", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            // If there are no more members in the chat, delete the chat
                            chatRef.removeValue().addOnCompleteListener { deleteTask ->
                                if (deleteTask.isSuccessful) {
                                    // Chat deleted successfully
                                    Toast.makeText(context, "Chat deleted successfully", Toast.LENGTH_SHORT).show()
                                    val action = ChatDetailsDirections.actionChatDetails2ToChatMenu()
                                    findNavController().navigate(action)
                                } else {
                                    // Chat deletion failed
                                    Toast.makeText(context, "Failed to delete the chat", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    } else {
                        membersRef.setValue(members).addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                // User removed successfully
                                Toast.makeText(context, "Left the chat", Toast.LENGTH_SHORT).show()
                                val action = ChatDetailsDirections.actionChatDetails2ToChatMenu()
                                findNavController().navigate(action)
                            } else {
                                // User removal failed
                                Toast.makeText(context, "Failed to leave the chat", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                } else {
                    Toast.makeText(context, "You are not a member of this chat", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "leaveChat:onCancelled", databaseError.toException())
            }
        })
    }

    private fun dismissPopupWindow() {
        if (popupWindow.isShowing) {
            popupWindow.dismiss()
        }
    }

    private fun requestCameraPermission(): Boolean {
        var permissionGranted = false

        // If system os is Marshmallow or Above, we need to request runtime permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val cameraPermissionNotGranted = ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_DENIED
            if (cameraPermissionNotGranted) {
                val permission = arrayOf(Manifest.permission.CAMERA)

                // Display permission dialog
                requestPermissions(permission, CAMERA_PERMISSION_CODE)
            } else {
                // Permission already granted
                permissionGranted = true
            }
        } else {
            // Android version earlier than M -> no need to request permission
            permissionGranted = true
        }

        return permissionGranted
    }

    // Handle Allow or Deny response from the permission dialog
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                openCameraInterface()
            } else {
                // Permission was denied
                showAlert("Camera permission was denied. Unable to take a picture.")
            }
        }
    }

    private fun openCameraInterface() {
        if (imageUriList.size < 10) {
            val values = ContentValues()
            values.put(MediaStore.Images.Media.TITLE, getString(R.string.take_picture))
            values.put(
                MediaStore.Images.Media.DESCRIPTION,
                getString(R.string.take_picture_description)
            )
            imageUri = activity?.contentResolver?.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            )

            // Create camera intent
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)

            // Launch intent
            startActivityForResult(intent, IMAGE_CAPTURE_CODE)
        } else {
            // Show a message indicating that the maximum number of images has been reached
            showAlert("You can only take a maximum of 10 images.")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Check if the result is OK
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                IMAGE_CAPTURE_CODE -> {
                    processCapturedImage()
                    updateRecyclerViewVisibility()
                }

                PICK_DOCUMENT_REQUEST_CODE -> {
                    // Process the selected documents
                    val selectedImages: MutableList<Uri> = mutableListOf()

                    // Check if multiple images were selected
                    if (data?.clipData != null) {
                        val count = data.clipData!!.itemCount
                        val remainingCapacity = 10 - imageUriList.size
                        val numToAdd = minOf(count, remainingCapacity)
                        for (i in 0 until numToAdd) {
                            val imageUri = data.clipData!!.getItemAt(i).uri
                            // Check if the image is already in the list
                            if (!imageUriList.contains(imageUri)) {
                                selectedImages.add(imageUri)
                            }
                        }
                    } else if (data?.data != null) {
                        // Only one image was selected
                        val imageUri = data.data!!
                        // Check if the image is already in the list
                        if (!imageUriList.contains(imageUri)) {
                            selectedImages.add(imageUri)
                        }
                    }

                    // Add the selected images to the list
                    imageUriList.addAll(selectedImages)

                    // Notify the adapter that the data set has changed
                    imageAdapter.notifyDataSetChanged()

                    // Show an alert if the maximum limit is reached
                    if (imageUriList.size >= 10) {
                        showAlert("You have reached the maximum limit of 10 images.")
                    }

                    updateRecyclerViewVisibility()

                }
            }
        } else {
            // Handle other cases
            showAlert("Operation failed")
        }
    }

    private fun processCapturedImage() {
        // Check if imageUri is not null
        imageUri?.let { uri ->
            val filePath = uri.path ?: return
            val mimeType = context?.contentResolver?.getType(uri)
            if (mimeType?.startsWith("image/") == true) {
                // Valid image, add to list and update adapter
                imageUriList.add(uri)
                imageAdapter.notifyDataSetChanged()
            } else {
                // Show an error message for non-image files
                showAlert("Invalid file format. Only images allowed.")
            }
        }
    }

    private fun showAlert(message: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage(message)
        builder.setPositiveButton(getString(R.string.ok_button_title), null)

        val dialog = builder.create()
        dialog.show()
    }

    private lateinit var imageAdapter: ImageAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val editTextMessage = view.findViewById<TextInputEditText>(R.id.editTextMessage)
        editTextMessage.maxLines = 5

        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        imageAdapter = ImageAdapter(imageUriList, this) // Initialize imageAdapter here
        recyclerView.adapter = imageAdapter

        view.findViewById<ImageView>(R.id.leftIcon).setOnClickListener {
            selectDocument(view) // Call the selectDocument method
            updateRecyclerViewVisibility()
        }

        view.findViewById<ImageView>(R.id.rightIcon).setOnClickListener {
            // Request permission
            val permissionGranted = requestCameraPermission()
            if (permissionGranted) {
                // Open the camera interface
                openCameraInterface()
                updateRecyclerViewVisibility()
            }
        }

        updateRecyclerViewVisibility()

        loadMessages(chatId)
    }

    override fun onRemoveImageClick(position: Int) {
        TODO("Not yet implemented")
    }

    override fun updateRecyclerViewVisibility() {
        val recyclerView: RecyclerView = requireView().findViewById(R.id.recyclerView)
        recyclerView.visibility = if (imageUriList.isNotEmpty()) View.VISIBLE else View.GONE
    }

    fun selectDocument(view: View) {
        if (imageUriList.size < 10) {
            openDocumentPicker()
        } else {
            // Show a message indicating that the maximum number of images has been reached
            showAlert("You can only take a maximum of 10 images.")
        }
    }

    private val PICK_DOCUMENT_REQUEST_CODE = 102

    private fun openDocumentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/*" // Allow users to select image files
//        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true) // Enable multiple selection
        startActivityForResult(intent, PICK_DOCUMENT_REQUEST_CODE)
    }

    private fun sendMessage(
        chatId: String,
        messageContent: String,
        imageUriList: List<Uri>
    ) {
        // Format the date and time
        val formattedDateTime = getMalaysiaDateTime()

        //        var senderId: String = "KC99FVvo2hRlC7MbJX2P9E3lRh13"

        // Get sender id (the one that logs in)
        var senderId: String = ""

        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser

        if (currentUser != null) {
            // User is signed in
            senderId = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $senderId")
        }

        // Upload images if available
        val imageUrls = mutableListOf<String>()
        val tasks = mutableListOf<Task<Uri>>()
        for (imageUri in imageUriList) {
            val task = uploadImage(imageUri, chatId, senderId, formattedDateTime)
            tasks.add(task)
        }

        Tasks.whenAllComplete(tasks)
            .addOnSuccessListener { result ->
                for (taskResult in result) {
                    if (taskResult.isSuccessful) {
                        val uri = taskResult.result as Uri
                        imageUrls.add(uri.toString())
                    }
                }

                // Send the message
                sendTextMessage(
                    requireContext(),
                    chatId,
                    receiverId,
                    messageContent,
                    imageUrls,
                    senderId,
                    formattedDateTime
                )

                // Update the last message and datetime
                updateLastMessageAndDatetime(chatId, messageContent, imageUrls, formattedDateTime)
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "Error uploading images", exception)
                // Handle the error
            }
    }

    private fun updateLastMessageAndDatetime(
        chatId: String,
        message: String,
        imageUrls: List<String>,
        datetime: String
    ) {
        val database = FirebaseDatabase.getInstance()
        val chatRef = database.getReference("Chats").child(chatId)

        val lastMessageMap = HashMap<String, Any>()

        if (message.isNotEmpty() && !imageUrls.isNullOrEmpty()) {
            // If there's a message and no image, set it as the last message
            lastMessageMap["lastMessage"] = "\uD83D\uDCF7 $message"
        } else if (message.isNotEmpty()) {
            // If there's only a message, set it as the last message
            lastMessageMap["lastMessage"] = message
        } else if (!imageUrls.isNullOrEmpty()) {
            // If there's no message but image, set the last message as image
            lastMessageMap["lastMessage"] = "\uD83D\uDCF7 Image"
        } else {
            lastMessageMap["lastMessage"] = ""
        }

        lastMessageMap["lastMsgDateTime"] = datetime

        chatRef.updateChildren(lastMessageMap)
            .addOnSuccessListener {
                Log.d(TAG, "Last message and datetime updated successfully in the database.")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error updating last message and datetime in the database: ${e.message}")
            }
    }

    private fun sendTextMessage(
        context: Context,
        chatId: String,
        userId: String,
        chatMessage: String,
        imageUrls: List<String>,
        senderId: String,
        formattedDateTime: String
    ) {
        // Get a reference to the "Chats" node in Realtime Database
        val chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatId)
        val messageRef = FirebaseDatabase.getInstance().getReference("Messages").child(chatId)

        // Get group name
        chatRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val groupName = dataSnapshot.child("groupName").getValue(String::class.java)

                // Get sender name
                FirebaseDatabase.getInstance().getReference("Users").child(senderId)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(senderDataSnapshot: DataSnapshot) {
                            val senderName = senderDataSnapshot.child("username").getValue(String::class.java)

                            // Construct the message object for text message
                            val textMessage =
                                Message(chatId, chatMessage, imageUrls, senderId, receiverId, formattedDateTime)

                            // Create a new child node with a unique key and push the message data
                            val newTextMessageRef = messageRef.push()  // Push generates a unique key
                            newTextMessageRef.setValue(textMessage)
                                .addOnSuccessListener {
                                    Log.d(TAG, "Text message sent successfully: ${newTextMessageRef.key}")
                                }
                                .addOnFailureListener { e ->
                                    Log.w(TAG, "Error sending text message", e)
                                    // Handle the error appropriately
                                }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Log.w(TAG, "Failed to read sender name", error.toException())
                        }
                    })
            }

            override fun onCancelled(error: DatabaseError) {
                Log.w(TAG, "Failed to read group name", error.toException())
            }
        })
    }

    private fun uploadImage(
        imageUri: Uri,
        chatId: String,
        senderId: String,
        formattedDateTime: String
    ): Task<Uri> {
        val storageRef = Firebase.storage.reference
        val imageRef = storageRef.child("images/${imageUri.lastPathSegment}")

        // Upload image to Firebase Storage
        return imageRef.putFile(imageUri)
            .continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                imageRef.downloadUrl
            }
    }

    private fun loadMessages(chatId: String) {
        // Get a reference to the RecyclerView
        val recyclerView = view?.findViewById<RecyclerView>(R.id.msgRecyclerView)

        // Get a reference to the "messages" node in Realtime Database
        val dbRef = FirebaseDatabase.getInstance().getReference("Messages").child(chatId)

        // Read data from the database
        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val messages = mutableListOf<Message>()
                var lastMessage = ""
                var lastMessageDateTime = ""
                var imageUrls: List<String>? = null
                for (postSnapshot in dataSnapshot.children) {
                    val chatId = postSnapshot.child("chatId").getValue(String::class.java)
                    val chatMessage = postSnapshot.child("chatMessage").getValue(String::class.java)
                    val senderId = postSnapshot.child("senderId").getValue(String::class.java)
                    val receiverId = postSnapshot.child("receiverId").getValue(String::class.java)
                    val timestamp = postSnapshot.child("timestamp").getValue(String::class.java)

                    val chatImages = mutableListOf<String>()
                    for (imageSnapshot in postSnapshot.child("chatImages").children) {
                        val imageUrl = imageSnapshot.getValue(String::class.java)
                        if (imageUrl != null) {
                            chatImages.add(imageUrl)
                        }
                    }

                    if (chatId != null && chatMessage != null && senderId != null && receiverId != null && timestamp != null) {
                        lastMessage = chatMessage
                        lastMessageDateTime = timestamp
                        imageUrls = chatImages
                        val message = Message(
                            chatId,
                            chatMessage,
                            chatImages,
                            senderId,
                            receiverId,
                            timestamp
                        )
                        messages.add(message)
                    }
                }

                // Update last message and datetime
                updateLastMessageAndDatetime(
                    chatId,
                    lastMessage,
                    imageUrls ?: emptyList(),
                    lastMessageDateTime
                )

                // Check if messages list is empty
                if (messages.isEmpty()) {
                    Log.d(TAG, "loadMessages: No messages found")
                } else {
                    val adapter = MessageAdapter(messages, this@ChatDetails)
                    recyclerView?.adapter = adapter
                    adapter.notifyDataSetChanged() // Notify adapter about data change

                    // Scroll to the bottom
                    recyclerView?.post {
                        recyclerView.scrollToPosition(messages.size - 1)
                    }
//
//                    // Listen for layout changes
//                    recyclerView?.viewTreeObserver?.addOnGlobalLayoutListener {
//                        // Scroll to the bottom again after layout changes
//                        recyclerView?.scrollToPosition(messages.size - 1)
//                    }

                    Log.d(TAG, "loadMessages: Updated adapter with ${messages.size} messages")
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "loadMessages:onCancelled", databaseError.toException())
            }
        })
    }

    fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur") // Malaysia time zone
        val malaysiaLocale = Locale("ms", "MY") // Malaysia locale
        val dateFormat =
            SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale) // Adjust format as needed
        dateFormat.timeZone = malaysiaTimeZone

        return dateFormat.format(Date())
    }

    override fun onItemLongClick(message: Message) {
        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        var loggedinUser: String = ""

        if (currentUser != null) {
            // User is signed in
            loggedinUser = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $loggedinUser")
        }

//        val loggedInUser = "1" // Logged in user ID

//        var loggedinUser: String = "KC99FVvo2hRlC7MbJX2P9E3lRh13"

        val options: List<String>
        if (message.senderId == loggedinUser) {
            options = mutableListOf<String>("Copy Text", "Delete Message")
        } else {
            options = mutableListOf<String>("Copy Text")
        }

        val builder = AlertDialog.Builder(requireContext())
        builder.setItems(options.toTypedArray()) { _, which ->
            when (which) {
                0 -> {
                    // Copy text option selected
                    copyToClipboard(message.chatMessage)
                }

                1 -> {
                    // Delete option selected
                    showDeleteMessageConfirmation(message)
                }
            }
        }
        builder.show()
    }

    private fun showDeleteMessageConfirmation(message: Message) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to delete this message?")
        builder.setPositiveButton("Delete") { _, _ ->
            deleteMessage(message)
        }
        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun copyToClipboard(text: String) {
        val clipboard =
            requireActivity().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("copiedText", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(requireContext(), "Text copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    private fun deleteMessage(message: Message) {
        // Get a reference to the "messages" node in Realtime Database
        val dbRef = FirebaseDatabase.getInstance().getReference("Messages").child(chatId)

        // Query to find the message to delete
        val query = dbRef.orderByChild("timestamp").equalTo(message.timestamp)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // Loop through each message
                for (snapshot in dataSnapshot.children) {
                    // Check if the current message matches the message to be deleted
                    if (snapshot.exists() && snapshot.getValue(Message::class.java) == message) {
                        // Remove the message from the database
                        snapshot.ref.removeValue()
                            .addOnSuccessListener {
                                Log.d(TAG, "Message deleted successfully")

                                // Remove the deleted message from the messageList
                                val position = messageList.indexOf(message)
                                if (position != -1) {
                                    messageList.removeAt(position)
                                    messageAdapter.notifyItemRemoved(position)
                                }

                                // Update the last message and datetime
                                updateLastMessageAndDatetime(chatId)

                            }
                            .addOnFailureListener { e ->
                                Log.e(TAG, "Error deleting message", e)
                                // Handle the error appropriately
                            }
                        break // Exit the loop after deleting the message
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "Error deleting message:", databaseError.toException())
                // Handle the error appropriately
            }
        })
    }

//    private fun deleteAllMessages(chatId: String) {
//        // Get a reference to the "Messages" node for the chat
//        val dbRef = FirebaseDatabase.getInstance().getReference("Messages").child(chatId)
//
//        // Attach a single event listener to delete all messages
//        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
//            override fun onDataChange(dataSnapshot: DataSnapshot) {
//                // Loop through each message and remove it
//                for (snapshot in dataSnapshot.children) {
//                    snapshot.ref.removeValue()
//                        .addOnSuccessListener {
//                            Log.d(TAG, "Message deleted successfully")
//                            // Update the message list after successful deletion
//                            val message = snapshot.getValue(Message::class.java)
//                            message?.let {
//                                messageList.remove(it)
//                                // Notify the adapter about the data change
//                                messageAdapter.notifyDataSetChanged()
//                                // Update the last message and datetime
//                                updateLastMessageAndDatetime(chatId)
//                            }
//                        }
//                        .addOnFailureListener { e ->
//                            Log.e(TAG, "Error deleting message:", e)
//                            // Handle the error appropriately
//                        }
//                }
//            }
//
//            override fun onCancelled(databaseError: DatabaseError) {
//                Log.w(TAG, "Error deleting messages:", databaseError.toException())
//                // Handle the error appropriately
//            }
//        })
//    }

    private fun updateLastMessageAndDatetime(chatId: String) {
        val database = FirebaseDatabase.getInstance()
        val chatRef = database.getReference("Chats").child(chatId)

        // Get the last message in the chat
        val lastMessageQuery =
            database.getReference("Messages").child(chatId).orderByChild("timestamp").limitToLast(1)
        lastMessageQuery.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (postSnapshot in dataSnapshot.children) {
                    val lastMessage = postSnapshot.child("chatMessage").getValue(String::class.java)
                    val lastMessageDateTime =
                        postSnapshot.child("timestamp").getValue(String::class.java)
                    val imageUrls = postSnapshot.child("chatImages")
                        .getValue(object : GenericTypeIndicator<List<String>>() {})

                    // Update the last message and datetime
                    val lastMessageMap = HashMap<String, Any>()
                    if (lastMessage != "" && !imageUrls.isNullOrEmpty()) {
                        // If there's a message and no image, set it as the last message
                        lastMessageMap["lastMessage"] = "\uD83D\uDCF7 $lastMessage"
                    } else if (lastMessage != "") {
                        // If there's only a message, set it as the last message
                        lastMessageMap["lastMessage"] = "$lastMessage"
                    } else if (!imageUrls.isNullOrEmpty()) {
                        // If there's no message but image, set the last message as image
                        lastMessageMap["lastMessage"] = "\uD83D\uDCF7 Image"
                    } else {
                        lastMessageMap["lastMessage"] = ""
                    }

                    lastMessageMap["lastMsgDateTime"] = lastMessageDateTime ?: ""

//                    lastMessageMap["lastMsgDateTime"] = datetime

                    chatRef.updateChildren(lastMessageMap)
                        .addOnSuccessListener {
                            Log.d(
                                TAG,
                                "Last message and datetime updated successfully in the database."
                            )
                        }
                        .addOnFailureListener { e ->
                            Log.e(
                                TAG,
                                "Error updating last message and datetime in the database: ${e.message}"
                            )
                        }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "updateLastMessageAndDatetime:onCancelled", databaseError.toException())
            }
        })
    }
}