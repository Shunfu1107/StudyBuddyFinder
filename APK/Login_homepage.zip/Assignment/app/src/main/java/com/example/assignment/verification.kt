package com.example.assignment

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.assignment.databinding.ActivityVerificationBinding
import com.google.firebase.auth.FirebaseAuth
import java.util.Random

class verification : AppCompatActivity() {

    private lateinit var binding: ActivityVerificationBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVerificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        // Generate OTP
        val otp = generateOTP()

        // Send OTP via email
        val email = intent.getStringExtra("Email") ?: ""
        sendOTPByEmail(email, otp)

        binding.btnVerify.setOnClickListener {
            val enteredOTP = binding.etOTP.text.toString()

            if (enteredOTP == otp) {
                // OTP is correct, proceed with user registration
                val email = intent.getStringExtra("Email")
                val password = intent.getStringExtra("Password")

                if (!email.isNullOrEmpty() && !password.isNullOrEmpty()) {
                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                // Registration successful
                                Toast.makeText(this, "Registration successful.", Toast.LENGTH_SHORT).show()
                                // Proceed to the next screen or perform necessary actions
                                val intent = Intent(this, profile_setup::class.java)
                                intent.putExtra("Email", email)
                                intent.putExtra("Password", password)
                                startActivity(intent)
                            } else {
                                // Registration failed
                                Toast.makeText(this, "Registration failed.", Toast.LENGTH_SHORT).show()
                            }
                        }
                } else {
                    // Invalid email or password
                    Toast.makeText(this, "Invalid email or password.", Toast.LENGTH_SHORT).show()
                }
            } else {
                // OTP is incorrect
                Toast.makeText(this, "Invalid OTP. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generateOTP(): String {
        val random = Random()
        val otp = StringBuilder()
        repeat(6) {
            otp.append(random.nextInt(10))
        }
        return otp.toString()
    }

    private fun sendOTPByEmail(email: String, otp: String) {
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "message/rfc822"
        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
        intent.putExtra(Intent.EXTRA_SUBJECT, "Your OTP")
        intent.putExtra(Intent.EXTRA_TEXT, "Your OTP is: $otp")

        try {
            startActivity(Intent.createChooser(intent, "Send email..."))
        } catch (ex: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show()
        }
    }
}

