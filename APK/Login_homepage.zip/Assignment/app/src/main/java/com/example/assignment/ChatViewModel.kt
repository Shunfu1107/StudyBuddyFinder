package com.example.assignment

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ChatViewModel : ViewModel() {

    private val _chatList = MutableLiveData<List<ChatModel>>()
    val chatList: LiveData<List<ChatModel>>
        get() = _chatList

    init {
        fetchChatList()
    }

    fun fetchChatList() {
        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        var loggedInUser: String = ""

        if (currentUser != null) {
            // User is signed in
            loggedInUser = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $loggedInUser")
        }

//        val loggedInUser = "KC99FVvo2hRlC7MbJX2P9E3lRh13"
        val chatRef = FirebaseDatabase.getInstance().getReference("Chats")
        val userRef = FirebaseDatabase.getInstance().getReference("users")

        val tempChatList = mutableListOf<ChatModel>()

        val userChatsQuery = chatRef.orderByChild("userID").equalTo(loggedInUser)
        val userReceivedChatsQuery = chatRef.orderByChild("receiverID").equalTo(loggedInUser)
        val groupChatsQuery = chatRef.orderByChild("members")

        val childEventListener = object : ChildEventListener {
            override fun onChildAdded(dataSnapshot: DataSnapshot, previousChildName: String?) {
                handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                updateChatList(tempChatList)
            }

            override fun onChildChanged(dataSnapshot: DataSnapshot, previousChildName: String?) {
                handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                updateChatList(tempChatList)
            }

            override fun onChildRemoved(dataSnapshot: DataSnapshot) {
                val chatId = dataSnapshot.key ?: return
                tempChatList.removeAll { it.getChatId() == chatId }
                updateChatList(tempChatList)
            }

            override fun onChildMoved(dataSnapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "Error getting data: ", databaseError.toException())
            }
        }

        userChatsQuery.addChildEventListener(childEventListener)
        userReceivedChatsQuery.addChildEventListener(childEventListener)

        groupChatsQuery.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(dataSnapshot: DataSnapshot, previousChildName: String?) {
                val members = dataSnapshot.child("members").getValue(object : GenericTypeIndicator<List<String>>() {})
                if (members != null && loggedInUser in members) {
                    handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                    updateChatList(tempChatList)
                }
            }

            override fun onChildChanged(dataSnapshot: DataSnapshot, previousChildName: String?) {
                handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                updateChatList(tempChatList)
            }

            override fun onChildRemoved(dataSnapshot: DataSnapshot) {
//                val members = dataSnapshot.child("members").getValue(object : GenericTypeIndicator<List<String>>() {})
//                if (members != null && loggedInUser in members) {
//                    val chatId = dataSnapshot.key ?: return
//                    tempChatList.removeAll { it.getChatId() == chatId }
//                    updateChatList(tempChatList)
//                }
            }

            override fun onChildMoved(dataSnapshot: DataSnapshot, previousChildName: String?) {
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "Error getting data: ", databaseError.toException())
            }
        })
    }

    private fun updateChatList(chatList: MutableList<ChatModel>) {
        val individualChats = mutableListOf<ChatModel>()
        val groupChats = mutableListOf<ChatModel>()

        // Sort the chat list based on the "pinned" status
        chatList.forEach {
            if (it.getGroupName().isNullOrEmpty()) {
                individualChats.add(it)
            } else {
                val existingChatIndex = groupChats.indexOfFirst { chat -> chat.getChatId() == it.getChatId() }
                if (existingChatIndex != -1) {
                    groupChats[existingChatIndex] = it
                } else {
                    groupChats.add(it)
                }
            }
        }

        individualChats.sortByDescending { it.getPinned() }
        groupChats.sortByDescending { it.getPinned() }

        // Add individual chats first
        val updatedChatList = individualChats + groupChats

        // Update the LiveData with the sorted chat list
        _chatList.value = updatedChatList
    }


    private fun handleChatEvent(
        dataSnapshot: DataSnapshot,
        userRef: DatabaseReference,
        tempChatList: MutableList<ChatModel>,
        loggedInUser: String
    ) {
        val chatId = dataSnapshot.key ?: return
        val message = dataSnapshot.child("lastMessage").value?.toString() ?: ""
        val datetime = dataSnapshot.child("lastMsgDateTime").value?.toString() ?: ""
        val receiverId = dataSnapshot.child("receiverID").value?.toString() ?: ""
        val groupName = dataSnapshot.child("groupName").value?.toString() ?: ""
        val groupImgUrl = dataSnapshot.child("groupImageUrl").value?.toString() ?: ""
        val pinned = dataSnapshot.child("pinned").getValue(Boolean::class.java) ?: false
        val isGroupChat = groupName.isNotEmpty()

        Log.d(
            TAG,
            "Received Chat: $chatId, Message: $message, DateTime: $datetime, ReceiverID: $receiverId"
        )

        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        var loggedInUserId: String = ""

        if (currentUser != null) {
            // User is signed in
            loggedInUserId = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $loggedInUserId")
        }

//        val loggedInUserId = "KC99FVvo2hRlC7MbJX2P9E3lRh13" // Change this to the actual logged-in user ID

        if (isGroupChat) {
            // Print group name
            Log.d(TAG, "Group chat: $groupName")

            val chatModel = ChatModel(
                chatId,
                "",
                groupName,
                message,
                datetime,
                groupImgUrl,
                groupName,
                pinned
            )

            // Add or update chat in the list
            val existingChatIndex = tempChatList.indexOfFirst { it.getChatId() == chatId }
            if (existingChatIndex != -1) {
                tempChatList[existingChatIndex] = chatModel
            } else {
                tempChatList.add(chatModel)
            }
        } else {
            val receiverUserRef = if (receiverId == loggedInUserId) {
                userRef.child(loggedInUserId)
            } else {
                userRef.child(receiverId)
            }

            receiverUserRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(userSnapshot: DataSnapshot) {
                    if (userSnapshot.exists()) {
                        val profilePicURL = userSnapshot.child("photoUrl").value?.toString() ?: ""
                        val actualReceiverId =
                            if (receiverId == loggedInUserId) receiverId else receiverId
                        val username = userSnapshot.child("name").value?.toString() ?: ""

                        Log.d(TAG, "Receiver name: $username")

                        val chatModel = ChatModel(
                            chatId,
                            actualReceiverId,
                            "",
                            message,
                            datetime,
                            profilePicURL,
                            username,
                            pinned
                        )

                        // Add or update chat in the list
                        val existingChatIndex =
                            tempChatList.indexOfFirst { it.getReceiverId() == actualReceiverId }
                        if (existingChatIndex != -1) {
                            tempChatList[existingChatIndex] = chatModel
                        } else {
                            tempChatList.add(chatModel)
                        }

                        // Sort the chat list based on the "pinned" status
                        tempChatList.sortByDescending { it.getPinned() }

                        // Update the LiveData with the sorted chat list
                        _chatList.value = tempChatList.distinctBy { it.getChatId() }
                    } else {
                        Log.w(TAG, "User does not exist")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.w(TAG, "Error getting user data: ", error.toException())
                }
            })
        }
    }

    fun pinChat(chatId: String, isPinned: Boolean) {
        val chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatId)
        chatRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    chatRef.child("pinned").setValue(isPinned)
                        .addOnSuccessListener {
                            Log.d(TAG, "Chat pinned successfully.")
                        }
                        .addOnFailureListener { e ->
                            Log.e(TAG, "Error pinning chat: $e")
                        }
                } else {
                    Log.e(TAG, "Chat does not exist.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Error pinning chat: ${error.message}")
            }
        })

        updateChatList()
    }

    fun unpinChat(chatId: String) {
        val chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatId)
        chatRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    chatRef.child("pinned").setValue(false)
                        .addOnSuccessListener {
                            Log.d(TAG, "Chat unpinned successfully.")
                        }
                        .addOnFailureListener { e ->
                            Log.e(TAG, "Error unpinning chat: $e")
                        }
                } else {
                    Log.e(TAG, "Chat does not exist.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Error unpinning chat: ${error.message}")
            }
        })

        updateChatList()
    }

    fun deleteChat(chatId: String) {
        val chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatId)
        chatRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val senderId = snapshot.child("userID").value.toString()
                    val receiverId = snapshot.child("receiverID").value.toString()

                    val firebaseAuth = FirebaseAuth.getInstance()
                    val currentUser = firebaseAuth.currentUser
                    var loggedInUserId: String = ""

                    if (currentUser != null) {
                        // User is signed in
                        loggedInUserId = currentUser.uid
                        // Use userId for further actions
                        Log.d("User", "Current user ID: $loggedInUserId")

                        // Check if the current user is sender or receiver
                        if (loggedInUserId == senderId || loggedInUserId == receiverId) {
                            chatRef.removeValue()
                                .addOnSuccessListener {
                                    Log.d(TAG, "Chat deleted successfully.")
                                    // Update chat list after successful deletion
                                    updateChatList()
                                }
                                .addOnFailureListener { e ->
                                    Log.e(TAG, "Error deleting chat: $e")
                                }
                        } else {
                            Log.e(TAG, "Current user is neither sender nor receiver.")
                        }
                    } else {
                        Log.e(TAG, "Current user is not signed in.")
                    }
                } else {
                    Log.e(TAG, "Chat does not exist.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Error deleting chat: ${error.message}")
            }
        })
    }

    private fun updateChatList() {
        val firebaseAuth = FirebaseAuth.getInstance()
        val currentUser = firebaseAuth.currentUser
        var loggedInUser: String = ""

        if (currentUser != null) {
            // User is signed in
            loggedInUser = currentUser.uid
            // Use userId for further actions
            Log.d("User", "Current user ID: $loggedInUser")
        }
//        val loggedInUser = "KC99FVvo2hRlC7MbJX2P9E3lRh13"

        val chatRef = FirebaseDatabase.getInstance().getReference("Chats")
        val userRef = FirebaseDatabase.getInstance().getReference("users")

        val tempChatList = mutableListOf<ChatModel>()

        val userChatsQuery = chatRef.orderByChild("userID").equalTo(loggedInUser)
        val userReceivedChatsQuery = chatRef.orderByChild("receiverID").equalTo(loggedInUser)
        val groupChatsQuery = chatRef.orderByChild("members")

        val childEventListener = object : ChildEventListener {
            override fun onChildAdded(dataSnapshot: DataSnapshot, previousChildName: String?) {
                handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                _chatList.value = tempChatList
            }

            override fun onChildChanged(dataSnapshot: DataSnapshot, previousChildName: String?) {
                handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                _chatList.value = tempChatList
            }

            override fun onChildRemoved(dataSnapshot: DataSnapshot) {
                // Handle chat removed event
                val chatId = dataSnapshot.key ?: return
                tempChatList.removeAll { it.getChatId() == chatId }
                _chatList.value = tempChatList
            }

            override fun onChildMoved(dataSnapshot: DataSnapshot, previousChildName: String?) {
                // Handle chat moved event
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error
                Log.w(TAG, "Error getting data: ", databaseError.toException())
            }
        }

        userChatsQuery.addChildEventListener(childEventListener)
        userReceivedChatsQuery.addChildEventListener(childEventListener)

        // For group chats, we don't want to add the same chat twice
        groupChatsQuery.addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(dataSnapshot: DataSnapshot, previousChildName: String?) {
                val members = dataSnapshot.child("members").getValue(object : GenericTypeIndicator<List<String>>() {})
                if (members != null && loggedInUser in members) {
                    handleChatEvent(dataSnapshot, userRef, tempChatList, loggedInUser)
                    _chatList.value = tempChatList
                }
            }

            override fun onChildChanged(dataSnapshot: DataSnapshot, previousChildName: String?) {
                // Handle chat changed event for group chats if necessary
                val members = dataSnapshot.child("members").getValue(object : GenericTypeIndicator<List<String>>() {})
                if (members != null && loggedInUser in members) {
                    val chatId = dataSnapshot.key ?: return
                    val updatedChat = dataSnapshot.getValue(ChatModel::class.java) ?: return
                    val existingIndex = tempChatList.indexOfFirst { it.getChatId() == chatId }
                    if (existingIndex != -1) {
                        tempChatList[existingIndex] = updatedChat
                        _chatList.value = tempChatList
                    }
                }
            }

            override fun onChildRemoved(dataSnapshot: DataSnapshot) {
                // Handle chat removed event for group chats if necessary
                val members = dataSnapshot.child("members").getValue(object : GenericTypeIndicator<List<String>>() {})
                if (members != null && loggedInUser in members) {
                    val chatId = dataSnapshot.key ?: return
                    tempChatList.removeAll { it.getChatId() == chatId }
                    _chatList.value = tempChatList
                }
            }

            override fun onChildMoved(dataSnapshot: DataSnapshot, previousChildName: String?) {
                // Handle chat moved event for group chats if necessary
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle error for group chats if necessary
                Log.w(TAG, "Error getting data: ", databaseError.toException())
            }
        })
    }

    companion object {
        private const val TAG = "ChatViewModel"
    }
}
