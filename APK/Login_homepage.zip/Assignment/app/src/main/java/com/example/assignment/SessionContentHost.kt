package com.example.assignment

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment.Adapter.SessionContentHostAdapter
import com.example.assignment.Data.SessionContent
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class SessionContentHost : Fragment() , SessionContentHostAdapter.OnItemClickListener{

    private lateinit var recyclerViewSessionContentHost: RecyclerView
    private var sessionContentList: ArrayList<SessionContent> = ArrayList()
    private lateinit var dbRefSessionContent: DatabaseReference
    private lateinit var sessionID:String
    private lateinit var sessionName: String
    private lateinit var details: String
    private lateinit var startTime: String
    private lateinit var date: String
    private lateinit var endTime: String


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_session_content_host, container, false)
        val btnCreateSessionPost: ImageButton = view.findViewById(R.id.btnCreateSessionPost)


        sessionID = arguments?.getString("sessionID") ?: ""
        sessionName= arguments?.getString("sessionName") ?: ""
        details = arguments?.getString("sessionDetails") ?: ""
        date = arguments?.getString("sessionDate") ?: ""
        startTime = arguments?.getString("sessionStartTime") ?: ""
        endTime = arguments?.getString("sessionEndTime") ?: ""

        recyclerViewSessionContentHost = view.findViewById(R.id.recyclerViewSessionContentHost)
        recyclerViewSessionContentHost.layoutManager = LinearLayoutManager(context)
        dbRefSessionContent = FirebaseDatabase.getInstance().getReference("SessionContent")
        val tvSessionName :TextView= view.findViewById(R.id.tvSessionName)
        val tvDetails:TextView= view.findViewById(R.id.tvDetails)
        val tvDate:TextView = view.findViewById(R.id.tvStartTime)
        val tvStartTime:TextView = view.findViewById(R.id.tvDate)
        val tvEndTime:TextView= view.findViewById(R.id.tvEndTime)
        tvSessionName.text = arguments?.getString("sessionName") ?: ""
        tvDetails.text = arguments?.getString("sessionDetails") ?: ""
        tvDate.text = arguments?.getString("sessionDate") ?: ""
        tvStartTime.text = arguments?.getString("sessionStartTime") ?: ""
        tvEndTime.text = arguments?.getString("sessionEndTime") ?: ""


        btnCreateSessionPost.setOnClickListener {
            val action =
                SessionContentHostDirections.actionSessionContentHostToSessionContentHostAdd(sessionID,sessionName, details, date, startTime, endTime)
            findNavController().navigate(action)
        }


fetchUserSessionContentData()

        return view
    }

    private fun fetchUserSessionContentData() {
        dbRefSessionContent.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                sessionContentList.clear()

                if (snapshot.exists()) {
                    for (studySessionSnap in snapshot.children) {
                        val sessionContent = studySessionSnap.getValue(SessionContent::class.java)
                        if (sessionContent != null && sessionContent.sessionID == sessionID) {

                            sessionContentList.add(sessionContent!!)

                        }

                    }
                    recyclerViewSessionContentHost.adapter =
                        SessionContentHostAdapter(sessionContentList,this@SessionContentHost)


                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
            }
        })
    }

    override fun onItemClickDeleteContent(sessionContentID: String) {
        val builder = AlertDialog.Builder(requireContext())
        builder.setMessage("Are you sure you want to Delete?")
            .setCancelable(false)
            .setPositiveButton("Delete") { dialog, id ->
                // Delete selected note from database
                for (item in sessionContentList) {
                    if (sessionContentID == item.sessionContentID) {
                        dbRefSessionContent.child(item.sessionContentID!!).removeValue()
                            .addOnCompleteListener {
                                Toast.makeText(requireContext(), "Deleted", Toast.LENGTH_LONG).show()
                            }
                    }
                }
            }
            .setNegativeButton("Cancel") { dialog, id ->
                // Dismiss the dialog
                dialog.dismiss()
            }
        val alert = builder.create()
        alert.show()
    }

    override fun onItemClickEditContent(sessionContentID: String) {

        val action = SessionContentHostDirections.actionSessionContentHostToSessionContentHostEdit(sessionContentID,sessionID,sessionName, details, date, startTime, endTime)
        findNavController().navigate(action)
            }

    }



//private fun fetchUserSessionContentData() {
//    dbRefSessionContent.addValueEventListener(object : ValueEventListener {
//        override fun onDataChange(snapshot: DataSnapshot) {
//
//            sessionContentList.clear()
//
//            if (snapshot.exists()) {
//                for (studySessionSnap in snapshot.children) {
//                    val sessionContent = studySessionSnap.getValue(SessionContent::class.java)
//                    if (sessionContent != null && sessionContent.sessionid == sessionID) {
//
//                        sessionContentList.add(sessionContent!!)
//
//                    }
//
//                }
//                recyclerViewSessionContentHost.adapter =
//                    SessionContentAdapter(sessionContentList)
//
//
//            }
//        }
//
//        override fun onCancelled(error: DatabaseError) {
//            Toast.makeText(requireContext(), "Error: $error", Toast.LENGTH_LONG).show()
//        }
//    })
//}