package com.example.assignment

import android.content.Intent
import android.os.Bundle
import android.service.controls.ControlsProviderService.TAG
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.assignment.databinding.ActivtiyHomepagePostBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone


class HomepagePostActivity : AppCompatActivity() {
    var imageUrl = ""
    private lateinit var binding: ActivtiyHomepagePostBinding
    private lateinit var postId: String
    private lateinit var commentRecyclerView: RecyclerView
    private lateinit var commentAdapter: CommentAdapter
    private val comments: MutableList<Comment> = mutableListOf()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivtiyHomepagePostBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle = intent.extras
        if (bundle != null) {
            binding.detailDesc.text = bundle.getString("Description")
            binding.detailTitle.text = bundle.getString("Title")

            imageUrl = bundle.getString("Image") ?: ""
            if (imageUrl.isNotEmpty()) {
                Glide.with(this).load(imageUrl).into(binding.detailImage)
            }

            postId = bundle.getString("PostId") ?: ""
        } else {
            // Handle the case where the intent extras are null
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show()
            finish() // Close the activity
        }

        commentRecyclerView = findViewById(R.id.commentRecyclerView)
        commentRecyclerView.layoutManager = LinearLayoutManager(this)
        commentAdapter = CommentAdapter(comments)
        commentRecyclerView.adapter = commentAdapter



        val fabComment = findViewById<FloatingActionButton>(R.id.fabComment)
        fabComment.setOnClickListener {
            // Open the CommentsActivity to view comments
            val intent = Intent(this, CommentActivity::class.java)
            intent.putExtra("postId", postId)
            startActivity(intent)
        }

        retrieveCommentsFromFirebase()


    }

    private fun retrieveCommentsFromFirebase() {
        val databaseReference = FirebaseDatabase.getInstance().getReference("Comments").child(postId)
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                comments.clear()
                for (snapshot in dataSnapshot.children) {
                    val comment = snapshot.getValue(Comment::class.java)
                    comment?.let { comments.add(it) }
                }
                commentAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e(TAG, "retrieveCommentsFromFirebase:onCancelled", databaseError.toException())
            }
        })
    }

    private fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur") // Malaysia time zone
        val malaysiaLocale = Locale("ms", "MY") // Malaysia locale
        val dateFormat =
            SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale) // Adjust format as needed
        dateFormat.timeZone = malaysiaTimeZone

        return dateFormat.format(Date())
    }

}
