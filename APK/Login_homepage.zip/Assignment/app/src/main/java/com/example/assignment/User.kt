package com.example.assignment

data class User(
    val userID: String = "",
    val username: String = "",
    val profilePicURL: String? = null, // Optional, can be null if user doesn't have a PFP
    val emailAddress: String = ""
)
