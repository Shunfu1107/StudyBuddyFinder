
package com.example.assignment

import android.content.Intent
import android.os.Bundle
import android.service.controls.ControlsProviderService.TAG
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.assignment.databinding.ActivityDetailBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone


class DetailActivity : AppCompatActivity() ,CommentAdapter.OnCommentClickListener {
    var imageUrl = ""
    private lateinit var binding: ActivityDetailBinding
    private lateinit var postId: String
    private lateinit var commentRecyclerView: RecyclerView
    private lateinit var commentAdapter: CommentAdapter
    private val comments: MutableList<Comment> = mutableListOf()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle = intent.extras
        if (bundle != null) {
            binding.detailDesc.text = bundle.getString("Description")
            binding.detailTitle.text = bundle.getString("Title")

            imageUrl = bundle.getString("Image") ?: ""
            if (imageUrl.isNotEmpty()) {
                Glide.with(this).load(imageUrl).into(binding.detailImage)
            }

            postId = bundle.getString("PostId") ?: ""
        } else {
            // Handle the case where the intent extras are null
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show()
            finish() // Close the activity
        }



        val fabDelete = findViewById<FloatingActionButton>(R.id.fabDelete)
        fabDelete.setOnClickListener {
            if (postId.isNotEmpty()) {
                deletePost(postId)
            } else {
                Toast.makeText(this, "No postId available", Toast.LENGTH_SHORT).show()
            }
        }



        val fabEdit = findViewById<FloatingActionButton>(R.id.fabEdit)
        fabEdit.setOnClickListener {
            // Start the EditActivity with the details of the current post
            val intent = Intent(this, EditActivity::class.java)
            intent.putExtra("PostId", postId)
            intent.putExtra("Title", binding.detailTitle.text.toString())
            intent.putExtra("Description", binding.detailDesc.text.toString())
            intent.putExtra("Image", imageUrl)
            startActivity(intent)
        }


        commentRecyclerView = findViewById(R.id.commentRecyclerView)
        commentRecyclerView.layoutManager = LinearLayoutManager(this)
        commentAdapter = CommentAdapter(comments)
        commentRecyclerView.adapter = commentAdapter
        commentAdapter.setOnCommentClickListener(this)



        val fabComment = findViewById<FloatingActionButton>(R.id.fabComment)
        fabComment.setOnClickListener {
            // Open the CommentsActivity to view comments
            val intent = Intent(this, CommentActivity::class.java)
            intent.putExtra("postId", postId)
            startActivity(intent)
        }

        retrieveCommentsFromFirebase()


    }

    override fun onCommentClick(comment: Comment) {
        // Handle the click event for a comment here
        // Pass both the post ID and comment ID to CommentDetailActivity
        val intent = Intent(this, CommentDetailActivity::class.java)
        intent.putExtra("postId", postId)
        intent.putExtra("commentId", comment.commentId) // Pass the comment ID
        intent.putExtra("commentContent", comment.commentText)
        startActivity(intent)
    }




    private fun retrieveCommentsFromFirebase() {
        val databaseReference = FirebaseDatabase.getInstance().getReference("Comments").child(postId)
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                comments.clear()
                for (snapshot in dataSnapshot.children) {
                    val comment = snapshot.getValue(Comment::class.java)
                    comment?.let { comments.add(it) }
                }
                commentAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e(TAG, "retrieveCommentsFromFirebase:onCancelled", databaseError.toException())
            }
        })
    }


    private fun editPost(postId: String, newTitle: String, newDescription: String) {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("HomePage").child(postId)
        val fabEdit = findViewById<FloatingActionButton>(R.id.fabEdit)
        // Get the Malaysia date and time
        val malaysiaDateTime = getMalaysiaDateTime()

        // Update the post details and post time in the database
        reference.child("dataTitle").setValue(newTitle)
        reference.child("dataDesc").setValue(newDescription)
        reference.child("postTime").setValue(malaysiaDateTime)
            .addOnSuccessListener {
                Toast.makeText(this, "Post updated successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to update post: ${e.message}", Toast.LENGTH_SHORT)
                    .show()
            }

        fabEdit.setOnClickListener {
            // Start the EditActivity with the details of the current post
            val intent = Intent(this, EditActivity::class.java)
            intent.putExtra("PostId", postId)
            intent.putExtra("Title", binding.detailTitle.text.toString())
            intent.putExtra("Description", binding.detailDesc.text.toString())
            intent.putExtra("Image", imageUrl)
            startActivity(intent)
        }
    }

    private fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur") // Malaysia time zone
        val malaysiaLocale = Locale("ms", "MY") // Malaysia locale
        val dateFormat =
            SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale) // Adjust format as needed
        dateFormat.timeZone = malaysiaTimeZone

        return dateFormat.format(Date())
    }


    private fun deletePost(postId: String) {
        val database = FirebaseDatabase.getInstance()
        val reference = database.getReference("HomePage").child(postId)

        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Confirm Deletion")
        alertDialogBuilder.setMessage("Are you sure you want to delete this post?")

        alertDialogBuilder.setPositiveButton("Yes") { dialogInterface, _ ->
            reference.removeValue()
                .addOnSuccessListener {
                    Toast.makeText(this, "Post deleted successfully", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to delete post: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            dialogInterface.dismiss()
        }

        alertDialogBuilder.setNegativeButton("No") { dialogInterface, _ ->
            dialogInterface.dismiss()
        }

        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }

}
