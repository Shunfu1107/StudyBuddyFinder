package com.example.assignment

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class CommentActivity : AppCompatActivity() {
    private lateinit var commentEditText: EditText
    private lateinit var postId: String // Make sure to initialize postId

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment)

        postId = intent.getStringExtra("postId") ?: ""

        commentEditText = findViewById(R.id.commentEditText)

        // Handle submitting comment to Firebase
        val submitButton = findViewById<Button>(R.id.submitButton)
        submitButton.setOnClickListener {
            val commentText = commentEditText.text.toString()
            if (commentText.isNotEmpty()) {
                saveCommentToDatabase(commentText)
            } else {
                Toast.makeText(this, "Comment cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveCommentToDatabase(commentText: String) {
        // Get the current user
        val currentUser = FirebaseAuth.getInstance().currentUser

        // Check if the current user is not null
        currentUser?.let { user ->
            // Get the user ID (UID)
            val userId = user.uid

            // Reference to the Firebase Users table
            val usersRef = FirebaseDatabase.getInstance().getReference("users").child(userId)

            // Retrieve user's name from Firebase Users table
            usersRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    // Check if the user exists in the Users table
                    if (snapshot.exists()) {
                        // Retrieve user's name
                        val userName =
                            snapshot.child("name").getValue(String::class.java) ?: "Unknown"

                        // Reference to the "Comments" node in the database with postId
                        val databaseReference =
                            FirebaseDatabase.getInstance().getReference("Comments").child(postId)

                        // Generate a unique commentId
                        val commentId = databaseReference.push().key ?: ""

                        // Get current Malaysia date and time as a formatted string
                        val malaysiaDateTime = getMalaysiaDateTime()

                        // Create a HashMap to store the comment data
                        val commentData = hashMapOf(
                            "userId" to userId,
                            "userName" to userName,
                            "commentText" to commentText,
                            "currentDate" to malaysiaDateTime // Save Malaysia date and time as a String
                        )

                        // Save the comment data to Firebase database under postId
                        databaseReference.child(commentId).setValue(commentData)
                            .addOnSuccessListener {
                                // Handle success
                                Toast.makeText(
                                    this@CommentActivity,
                                    "Comment saved successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                                finish()
                            }
                            .addOnFailureListener { exception ->
                                // Handle failure
                                Toast.makeText(
                                    this@CommentActivity,
                                    "Failed to save comment: ${exception.message}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                    } else {
                        // Handle case where user data doesn't exist
                        Toast.makeText(this@CommentActivity, "User data not found", Toast.LENGTH_SHORT)
                            .show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                    Toast.makeText(
                        this@CommentActivity,
                        "Failed to retrieve user's name",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }
}

    // Function to get current date and time in Malaysia time zone as a formatted string
    private fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur") // Malaysia time zone
        val malaysiaLocale = Locale("ms", "MY") // Malaysia locale
        val dateFormat =
            SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale) // Adjust format as needed
        dateFormat.timeZone = malaysiaTimeZone

        return dateFormat.format(Date())
    }


