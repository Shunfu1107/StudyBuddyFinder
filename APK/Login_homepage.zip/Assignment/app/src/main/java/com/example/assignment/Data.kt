package com.example.assignment

class DataClass {
    var dataTitle: String? = null
    var dataDesc: String? = null
    var dataImage: String? = null
    var postId: String? = null
    var authorEmail: String? = null // Add authorEmail property
    var postTime: String? = null
    var userName: String? = null // Add this line for user name

    constructor(dataTitle: String?, dataDesc: String?, dataImage: String?, postId: String?,  authorEmail: String?, postTime: String?, userName: String?) {
        this.dataTitle = dataTitle
        this.dataDesc = dataDesc
        this.dataImage = dataImage
        this.postId = postId
        this.authorEmail = authorEmail
        this.postTime = postTime
        this.userName = userName
    }

    constructor(){}
}
