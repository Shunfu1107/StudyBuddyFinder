package com.example.assignment


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class CommentAdapter(private val comments: List<Comment>) : RecyclerView.Adapter<CommentAdapter.CommentViewHolder>() {

    private var commentClickListener: OnCommentClickListener? = null

    interface OnCommentClickListener {
        fun onCommentClick(comment: Comment)

    }

    fun setOnCommentClickListener(listener: OnCommentClickListener) {
        this.commentClickListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_comment, parent, false)
        return CommentViewHolder(view)
    }

    override fun onBindViewHolder(holder: CommentViewHolder, position: Int) {
        val comment = comments[position]
        holder.bind(comment)
        holder.itemView.setOnClickListener {
            commentClickListener?.onCommentClick(comment)
        }
    }

    override fun getItemCount(): Int {
        return comments.size
    }


    inner class CommentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener  {
        private val commentText: TextView = itemView.findViewById(R.id.commentText)
        private val currentDate: TextView = itemView.findViewById(R.id.currentDate)
        private val userName: TextView = itemView.findViewById(R.id.tvUserComment)
        private lateinit var currentComment: Comment

        init {
            itemView.setOnClickListener(this)
        }

        fun bind(comment: Comment) {
            // Bind the properties of the Comment object to the appropriate views
            commentText.text = comment.commentText
            currentDate.text = comment.currentDate // Display stored timestamp directly
            userName.text = comment.userName
            currentComment = comment
        }

        override fun onClick(v: View) {
            commentClickListener?.onCommentClick(currentComment)
        }
    }


    // Function to get current date and time in Malaysia time zone
    private fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur") // Malaysia time zone
        val malaysiaLocale = Locale("ms", "MY") // Malaysia locale
        val dateFormat =
            SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale) // Adjust format as needed
        dateFormat.timeZone = malaysiaTimeZone

        return dateFormat.format(Date())
    }
}

