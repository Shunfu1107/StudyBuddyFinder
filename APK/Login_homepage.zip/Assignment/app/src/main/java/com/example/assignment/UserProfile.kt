package com.example.assignment


data class UserProfile(
    val photoUrl: String? = null,
    val name: String,
    val gender: String,
    val birthDate: String,
    val courseOfStudy: String
)