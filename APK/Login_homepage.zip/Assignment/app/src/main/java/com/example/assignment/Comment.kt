package com.example.assignment

data class Comment(
    val commentId: String = "",
    val postId: String = "",
    val userId: String = "",
    val commentText: String = "",
    val currentDate: String = "",
    var userName: String? = ""
) {
    constructor() : this("","","", "", "", "")
}
