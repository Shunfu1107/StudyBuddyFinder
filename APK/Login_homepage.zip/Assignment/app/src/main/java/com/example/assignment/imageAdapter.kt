package com.example.assignment

import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class ImageAdapter(private val imageUriList: MutableList<Uri>, private val listener: ImageAdapterListener) :
    RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    interface ImageAdapterListener {
        fun onRemoveImageClick(position: Int)
        fun updateRecyclerViewVisibility()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_image, parent, false)
        return ImageViewHolder(itemView)
    }

    fun onRemoveImageClick(position: Int) {
        if (position in 0 until imageUriList.size) { // Check if position is valid
            imageUriList.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, imageUriList.size)

            // Log to check if the item is removed
            Log.d("ImageAdapter", "Image removed at position: $position")

            // Notify the fragment to update the visibility of the RecyclerView
            listener.updateRecyclerViewVisibility()
        } else {
            Log.e("ImageAdapter", "Invalid position: $position")
        }
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val imageUri = imageUriList[position]
        holder.imageView.setImageURI(imageUri)

        holder.itemView.findViewById<ImageButton>(R.id.removeButton).setOnClickListener {
            onRemoveImageClick(position)
        }
    }

    override fun getItemCount(): Int = imageUriList.size

    inner class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.abc)
    }
}
