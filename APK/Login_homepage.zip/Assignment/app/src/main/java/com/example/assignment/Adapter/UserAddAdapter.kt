package com.example.assignment.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.example.assignment.Data.User
import com.example.assignment.R

class UserAddAdapter (private var userList: List<User>,private val listener: UserAddAdapter.OnItemClickListener) : RecyclerView.Adapter
<UserAddAdapter.MyViewHolder>() {
    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvUserNameADD: TextView = itemView.findViewById(R.id.tvUserNameADD)
        val ivPfpADD: ImageView = itemView.findViewById(R.id.ivPfpADD)
        val ivBtnAdd:ImageView = itemView.findViewById(R.id.ivBtnAdd)
    }

    fun setFilteredList(userList: List<User>) {
        this.userList = userList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.user_add_cell, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: UserAddAdapter.MyViewHolder, position: Int) {
        val currentItem = userList[position]
        Glide.with(holder.itemView.context)
            .load(userList[position].profilePicURL).transform(CircleCrop())
            .into(holder.ivPfpADD)
        holder.tvUserNameADD.text = userList[position].username

        holder.ivBtnAdd.setOnClickListener{
            holder.ivBtnAdd.setImageResource(R.drawable.baseline_check_24_blue)
            holder.ivBtnAdd.isEnabled=false
            listener.onItemClickADD(currentItem.userID!!)

        }
    }

    override fun getItemCount(): Int {
        return userList.size
    }
    interface OnItemClickListener {
        fun onItemClickADD(userID: String)
    }




}