package com.example.assignment

import android.net.Uri

data class Message(
    val chatId: String = "",
    val chatMessage: String = "",
    val chatImages: List<String> = emptyList(),
    val senderId: String = "",  // logged in userId
    val receiverId: String = "", // chat userId that was clicked
    val timestamp: String = ""
)