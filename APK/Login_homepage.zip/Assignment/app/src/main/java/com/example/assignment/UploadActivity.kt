package com.example.assignment


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.assignment.databinding.ActivityUploadBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class UploadActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUploadBinding
    private var imageURL: String? = null
    private var uri: Uri? = null
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val activityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                uri = data!!.data
                binding.uploadImage.setImageURI(uri)
            } else {
                Toast.makeText(this@UploadActivity, "No Image Selected", Toast.LENGTH_SHORT).show()
            }
        }
        binding.uploadImage.setOnClickListener {
            val photoPicker = Intent(Intent.ACTION_PICK)
            photoPicker.type = "image/*"
            activityResultLauncher.launch(photoPicker)
        }

        databaseReference = FirebaseDatabase.getInstance().getReference("users")

        binding.saveButton.setOnClickListener {
                saveData()
        }
    }

    private fun saveData() {
        val title = binding.uploadTitle.text.toString().trim()
        val desc = binding.uploadDesc.text.toString().trim()

        // Check if title and description are empty
        if (title.isEmpty() || desc.isEmpty()) {
            Toast.makeText(this@UploadActivity, "Title and Description cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        // Check if an image is selected
        if (uri == null) {
            Toast.makeText(this@UploadActivity, "Please select an image", Toast.LENGTH_SHORT).show()
            return
        }

        val storageReference = FirebaseStorage.getInstance().reference.child("Task Images")
            .child(uri!!.lastPathSegment!!)

        val builder = AlertDialog.Builder(this@UploadActivity)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        storageReference.putFile(uri!!).addOnSuccessListener { taskSnapshot ->
            val uriTask = taskSnapshot.storage.downloadUrl
            while (!uriTask.isComplete);
            val urlImage = uriTask.result
            imageURL = urlImage.toString()

            val postId = FirebaseDatabase.getInstance().getReference("HomePage").push().key
                uploadData(postId)

            dialog.dismiss()
        }.addOnFailureListener {
            dialog.dismiss()
        }
    }


    private fun uploadData(postId: String?) {
        val title = binding.uploadTitle.text.toString()
        val desc = binding.uploadDesc.text.toString()
        val malaysiaDateTime = getMalaysiaDateTime()

        // Get the current user
        val currentUser = FirebaseAuth.getInstance().currentUser

        // Check if the current user is not null
        currentUser?.let { user ->
            // Get the user ID (UID)
            val userId = user.uid

            // Reference to the Firebase Users table
            val usersRef = FirebaseDatabase.getInstance().getReference("users").child(userId)

            // Retrieve user's name from Firebase Users table
            usersRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    // Check if the user exists in the Users table
                    if (snapshot.exists()) {
                        // Retrieve user's name
                        val userName = snapshot.child("name").getValue(String::class.java) ?: "Unknown"

                        // Create a HashMap to store the data
                        val postData = hashMapOf(
                            "dataTitle" to title,
                            "dataDesc" to desc,
                            "dataImage" to imageURL,
                            "postId" to postId,
                            "authorEmail" to user.email,
                            "postTime" to malaysiaDateTime,
                            "userName" to userName
                        )

                        // Reference to the "HomePage" node in the database
                        val databaseReference = FirebaseDatabase.getInstance().getReference("HomePage")

                        // Set the post data under a unique postId
                        databaseReference.child(postId.toString()).setValue(postData)
                            .addOnSuccessListener {
                                // Handle success
                                Toast.makeText(
                                    this@UploadActivity, "Post saved successfully", Toast.LENGTH_SHORT
                                ).show()
                                finish()
                            }
                            .addOnFailureListener { e ->
                                // Handle failure
                                Toast.makeText(
                                    this@UploadActivity, "Failed to save post: ${e.message}", Toast.LENGTH_SHORT
                                ).show()
                            }

                        // Save post data to local database
                        val dataClass = DataClass(title, desc, imageURL, postId, user.email, malaysiaDateTime, userName)
                        savePostToDatabase(postId, dataClass)
                    } else {
                        // Handle case where user data doesn't exist
                        Toast.makeText(
                            this@UploadActivity, "User data not found", Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                    Toast.makeText(
                        this@UploadActivity, "Failed to retrieve user's name", Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }


    private fun savePostToDatabase(postId: String?, dataClass: DataClass) {
        FirebaseDatabase.getInstance().getReference("HomePage").child(postId!!)
            .setValue(dataClass).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this@UploadActivity, "Saved", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }.addOnFailureListener { e ->
                Toast.makeText(
                    this@UploadActivity, "Failed to save post: ${e.message}", Toast.LENGTH_SHORT
                ).show()
            }
    }

    private fun getMalaysiaDateTime(): String {
        val malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur")
        val malaysiaLocale = Locale("ms", "MY")
        val dateFormat = SimpleDateFormat("dd-MM-yyyy HH:mm", malaysiaLocale)
        dateFormat.timeZone = malaysiaTimeZone
        return dateFormat.format(Date())
    }
}
