package com.example.assignment

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase


class CommentDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comment_detail)

        val commentId = intent.getStringExtra("commentId")
        val commentContent = intent.getStringExtra("commentContent")
        val postId = intent.getStringExtra("postId")

        // Check if any of the data is null
        if (commentId != null && commentContent != null && postId != null) {
            // Display the comment content
            val commentTextView: TextView = findViewById(R.id.textViewCommentContent)
            commentTextView.text = commentContent

            val deleteButton: Button = findViewById(R.id.buttonDeleteComment)
            deleteButton.setOnClickListener {
                showDeleteConfirmationDialog(postId, commentId) // Pass both post ID and comment ID
            }
        } else {
            // Handle the case where data is missing
            Toast.makeText(this, "Error: Missing comment details", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun showDeleteConfirmationDialog(postId: String?, commentId: String?) {
        if (postId != null && commentId != null) {
            val alertDialogBuilder = AlertDialog.Builder(this)
            alertDialogBuilder.setTitle("Confirm Deletion")
            alertDialogBuilder.setMessage("Are you sure you want to delete this comment?")

            alertDialogBuilder.setPositiveButton("Yes") { dialogInterface, _ ->
                deleteComment(postId, commentId) // Call deleteComment function with post ID and comment ID
                dialogInterface.dismiss()
            }

            alertDialogBuilder.setNegativeButton("No") { dialogInterface, _ ->
                dialogInterface.dismiss()
            }

            val alertDialog = alertDialogBuilder.create()
            alertDialog.show()
        }
    }

    private fun deleteComment(postId: String, commentId: String) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("Comments").child(postId).child(commentId)
        databaseReference.removeValue()
            .addOnSuccessListener {
                Toast.makeText(this, "Comment deleted successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to delete comment: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

}